J's Auctions GitHub Build Ready Package
Regenerated downloadable ZIP.
