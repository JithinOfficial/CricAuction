# RDB Auction Manager - 1.1 Premium Export Update

## App identity
- App name: RDB Auction Manager
- Package: com.josco.jsauctionsleague
- Version code: 2
- Version name: 1.1-rdb-premium-export

This keeps the same package and included common signing key from the previous JS Auction League Manager ZIP, so APKs built from this project can update that app if the same release build workflow/key is used.

## Included updates
- Player catalogue settings expanded and corrected.
- Player catalogue PDF now dynamically follows every selected setting.
- Player catalogue redesigned as cricket/IPL-style premium player cards.
- Team PDF export redesigned as professional cricket team reveal posters.
- Fixture scheduling logic retained with no back-to-back team matches where possible.

## Build
Use GitHub Actions workflow or run:

./gradlew assembleRelease

Install the generated release APK:

app/build/outputs/apk/release/app-release.apk
