package com.josco.jsauctions;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation;
import android.os.Environment;
import java.io.OutputStream;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    // RDB cricket theme: deep navy + maroon + stadium gold.
    int bg = Color.rgb(4, 10, 22);
    int panel = Color.rgb(12, 24, 42);
    int panel2 = Color.rgb(18, 38, 62);
    int gold = Color.rgb(244, 184, 62);
    int blue = Color.rgb(36, 159, 184);
    int green = Color.rgb(22, 148, 104);
    int red = Color.rgb(177, 36, 47);
    int orange = Color.rgb(218, 112, 42);
    int text = Color.rgb(246, 248, 252);
    int muted = Color.rgb(190, 202, 216);

    LinearLayout root;
    SharedPreferences sp;
    JSONArray players = new JSONArray();
    JSONArray teams = new JSONArray();
    JSONArray deck = new JSONArray();
    JSONArray fixtures = new JSONArray();
    int currentIndex = -1;
    String pickTarget = "";
    String pdfMode = "ALL";
    String pdfTeam = "";
    int editingTeamIndex = -1;
    int roundNo = 0;
    boolean auctionEnded = false;

    String[] roles = {"Batsman", "Bowler", "All Rounder", "Wicket Keeper Batsman"};
    String[] bats = {"Right hand bat", "Left hand bat"};
    String[] bowls = {"Right arm fast", "Right arm medium", "Right arm off spin", "Right arm leg spin", "Left arm fast", "Left arm medium", "Left arm orthodox", "Left arm wrist spin", "None"};

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("db", 0);
        setDefaults();
        load();
        intro();
    }

    void setDefaults() {
        if (!sp.contains("playersPerTeam")) {
            sp.edit()
                    .putInt("playersPerTeam", 11)
                    .putBoolean("bench", false)
                    .putInt("benchCount", 2)
                    .putInt("maxBucket", 11000)
                    .putInt("basePoints", 300)
                    .putString("increments", "300-999:50\n1000-2999:100\n3000-99999:250")
                    .putString("auctionName", "KPL Season 1")
                    .putBoolean("auctionEnded", false)
                    .putInt("roundNo", 0)
                    .putInt("poolCount", 2)
                    .putString("fixtures", "[]")
                    .apply();
        }
    }

    void load() {
        try {
            players = new JSONArray(sp.getString("players", "[]"));
            teams = new JSONArray(sp.getString("teams", "[]"));
            deck = new JSONArray(sp.getString("deck", "[]"));
            fixtures = new JSONArray(sp.getString("fixtures", "[]"));
            currentIndex = sp.getInt("idx", -1);
            roundNo = sp.getInt("roundNo", 0);
            auctionEnded = sp.getBoolean("auctionEnded", false);
            ensurePlayerIds();
        } catch (Exception e) { }
    }

    void save() {
        sp.edit().putString("players", players.toString()).putString("teams", teams.toString()).putString("deck", deck.toString()).putString("fixtures", fixtures.toString()).putInt("idx", currentIndex).putInt("roundNo", roundNo).putBoolean("auctionEnded", auctionEnded).apply();
    }

    GradientDrawable bgShape(int color, int strokeColor, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (stroke > 0) g.setStroke(stroke, strokeColor);
        return g;
    }

    String cleanRole(String role) {
        if (role == null) return "";
        return role.replace("🏏", "").replace("⚡", "").replace("⭐", "").replace("🧤", "").trim();
    }



    String nextPlayerId() {
        int max = 0;
        try {
            for (int i = 0; i < players.length(); i++) {
                String id = players.getJSONObject(i).optString("pid", "").replaceAll("[^0-9]", "");
                if (id.length() > 0) {
                    int n = Integer.parseInt(id);
                    if (n > max) max = n;
                }
            }
        } catch (Exception e) { }
        return String.format(java.util.Locale.US, "%02d", max + 1);
    }

    void ensurePlayerIds() {
        try {
            boolean changed = false;
            for (int i = 0; i < players.length(); i++) {
                JSONObject pl = players.getJSONObject(i);
                String newId = String.format(java.util.Locale.US, "%02d", i + 1);
                if (!newId.equals(pl.optString("pid", ""))) {
                    pl.put("pid", newId);
                    changed = true;
                }
            }
            if (changed) sp.edit().putString("players", players.toString()).apply();
        } catch (Exception e) { }
    }

    void footer() {
        TextView f = tv("Owned by Team RDB • Creator: Josco\n© 2026 Team RDB. All rights reserved. This application, auction workflow, UI concepts, data structure and tournament management system are proprietary work of Team RDB. Unauthorized reproduction, redistribution, reverse engineering or commercial reuse is prohibited.", 12, Color.LTGRAY);
        f.setGravity(Gravity.CENTER);
        f.setPadding(12, 28, 12, 12);
        root.addView(f);
    }

    int totalSlots() { return sp.getInt("playersPerTeam", 11) + (sp.getBoolean("bench", false) ? sp.getInt("benchCount", 2) : 0); }
    int maxBucket() { return sp.getInt("maxBucket", 11000); }
    int basePoints() { return sp.getInt("basePoints", 300); }

    TextView tv(String s, int size, int c) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(c);
        v.setPadding(18, 10, 18, 10);
        return v;
    }


    TextView playerIdBadge(String pid) {
        if (pid == null || pid.trim().length() == 0) pid = "--";
        TextView v = tv("PLAYER ID  " + pid, 16, Color.BLACK);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setPadding(22, 12, 22, 12);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{gold, orange});
        g.setCornerRadius(34);
        g.setStroke(3, Color.WHITE);
        v.setBackground(g);
        v.setShadowLayer(0, 0, 0, Color.TRANSPARENT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 10, 0, 6);
        v.setLayoutParams(lp);
        return v;
    }

    TextView label(String s) {
        TextView v = tv(s, 14, muted);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    TextView title(String s) {
        TextView v = tv(s, 24, gold);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    GradientDrawable buttonShape(int color) {
        int end = darken(color, 42);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{color, end});
        g.setCornerRadius(30);
        g.setStroke(2, Color.argb(190, 244, 184, 62));
        return g;
    }

    int darken(int c, int amount) {
        return Color.rgb(Math.max(0, Color.red(c)-amount), Math.max(0, Color.green(c)-amount), Math.max(0, Color.blue(c)-amount));
    }

    Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(text);
        b.setShadowLayer(3, 0, 1, Color.BLACK);
        b.setBackground(buttonShape(color));
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(20, 16, 20, 16);
        return b;
    }

    void addBtn(String s, int color, View.OnClickListener l) {
        Button b = btn(s, color);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        root.addView(b, lp);
    }

    LinearLayout cardBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16, 16, 16, 16);
        box.setBackground(bgShape(panel, Color.rgb(67, 85, 130), 26, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 10, 0, 12);
        root.addView(box, lp);
        return box;
    }


    void intro() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(28, 28, 28, 28);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(2, 5, 14), Color.rgb(24, 6, 18), Color.rgb(4, 17, 30)});
        wrap.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(gd);
        frame.addView(new StadiumBackdrop(this), new FrameLayout.LayoutParams(-1, -1));
        frame.addView(wrap, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("rdblogo", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(320, 320);
        ilp.setMargins(0, 0, 0, 20);
        wrap.addView(logo, ilp);

        TextView app = title("RDB Auction Manager");
        app.setTextSize(32);
        app.setTextColor(gold);
        app.setShadowLayer(10, 0, 0, Color.rgb(160, 35, 45));
        wrap.addView(app);

        TextView tag = tv("Premium Cricket Auction Manager", 18, text);
        tag.setGravity(Gravity.CENTER);
        tag.setTypeface(Typeface.DEFAULT_BOLD);
        wrap.addView(tag);

        TextView own = tv("Owned By Team RDB", 16, gold);
        own.setGravity(Gravity.CENTER);
        wrap.addView(own);

        TextView cr = tv("Created By Josco", 15, muted);
        cr.setGravity(Gravity.CENTER);
        wrap.addView(cr);

        animateIn(logo, 0);
        animateIn(app, 350);
        animateIn(tag, 700);
        animateIn(own, 1050);
        animateIn(cr, 1350);

        new Handler().postDelayed(new Runnable() { public void run() { home(); } }, 3300);
    }

    void animateIn(View v, long delay) {
        v.setAlpha(0f);
        v.setTranslationY(50f);
        v.animate().alpha(1f).translationY(0f).setDuration(850).setStartDelay(delay).start();
    }

    void base(String screenTitle) {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 24, 18, 24);
        root.setBackgroundColor(bg);
        sv.addView(root);
        setContentView(sv);
        TextView h = title("RDB Auction Manager");
        root.addView(h);
        if (screenTitle != null && screenTitle.trim().length() > 0) {
            TextView sub = tv(screenTitle, 14, muted);
            sub.setGravity(Gravity.CENTER);
            root.addView(sub);
        }
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(text);
        e.setHintTextColor(muted);
        e.setSingleLine(false);
        e.setBackground(bgShape(panel2, Color.rgb(80, 100, 150), 18, 1));
        e.setPadding(16, 10, 16, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(e, lp);
        return e;
    }

    Spinner spin(String[] arr) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr) { public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; } public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }};
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    boolean teamHasIcon(String teamName) {
        try {
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if (teamName.equals(p.optString("team")) && "ICON".equals(p.optString("status"))) return true;
            }
        } catch (Exception e) { }
        return false;
    }

    Spinner teamSpinner(boolean includeEmptyMessage) {
        return teamSpinnerInternal(includeEmptyMessage, false);
    }

    Spinner iconAvailableTeamSpinner(boolean includeEmptyMessage) {
        return teamSpinnerInternal(includeEmptyMessage, true);
    }

    Spinner teamSpinnerInternal(boolean includeEmptyMessage, boolean onlyTeamsWithoutIcon) {
        ArrayList<String> list = new ArrayList<String>();
        try {
            for (int i = 0; i < teams.length(); i++) {
                String tn = teams.getJSONObject(i).optString("name");
                if (onlyTeamsWithoutIcon && teamHasIcon(tn)) continue;
                list.add(tn);
            }
        } catch (Exception e) { }
        if (list.size() == 0 && includeEmptyMessage) {
            list.add(onlyTeamsWithoutIcon && teams.length() > 0 ? "All teams already have icon player" : "No teams added");
        }
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {
            public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; }
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    void home() {
        base("");
        LinearLayout hero = cardBox();
        hero.setBackground(bgShape(Color.rgb(13, 24, 43), gold, 34, 2));
        hero.addView(tv("🏟️  " + sp.getString("auctionName", "KPL Season 1"), 24, gold));
        hero.addView(tv("Teams Registered: " + teams.length(), 16, text));
        hero.addView(tv("Players Registered: " + players.length(), 16, text));
        hero.addView(tv("Current Round: " + roundNo, 15, muted));
        addBtn("➕ Add Player", blue, v -> playerForm());
        addBtn("✏️ Manage / Edit Players", green, v -> managePlayers());
        addBtn("🛡️ Add Franchisee / Team", red, v -> teamForm());
        addBtn("🎙️ Start / Continue Auction", green, v -> auction());
        addBtn("📋 Teams, Logos & Squads", blue, v -> teamsView());
        addBtn("🔁 Unsold / Recall Buckets", orange, v -> buckets());
        addBtn("⚙️ Auction Settings", red, v -> settings());
        addBtn("⭐ Change Icon Player", gold, v -> changeIconScreen());
        addBtn("🏟️ Pools & Fixtures", orange, v -> fixturesSetup());
        addBtn("📄 Export All Teams PDF", green, v -> exportPdf());
        addBtn("📄 Export Separate Team PDF", blue, v -> exportTeamPdfScreen());
        addBtn("📘 Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
        addBtn("🧾 Player Catalogue PDF Settings", blue, v -> playerCatalogueSettings());
        addBtn("📅 Export Fixtures PDF", orange, v -> exportFixturesPdf());
        footer();
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, 5);
    }

    public void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 5 && c == RESULT_OK && d != null) {
            Uri u = d.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
            SharedPreferences.Editor ed = sp.edit();
            if ("photo".equals(pickTarget)) ed.putString("last_photo", u.toString());
            else if ("id".equals(pickTarget)) ed.putString("last_id", u.toString());
            else if ("teamLogo".equals(pickTarget)) ed.putString("last_team_logo", u.toString());
            ed.apply();
            toast("Image selected. Now press Save.");
        }
        if (r == 7 && c == RESULT_OK && d != null) {
            writePdf(d.getData());
        }
    }


    int indexOf(String[] arr, String val) {
        if (val == null) return 0;
        for (int i = 0; i < arr.length; i++) if (arr[i].equalsIgnoreCase(val.trim())) return i;
        return 0;
    }

    String safeText(EditText e) { return e.getText().toString().trim(); }

    void managePlayers() {
        base("Manage / Edit Players");
        if (players.length() == 0) {
            root.addView(tv("No players added yet.", 18, text));
            addBtn("Add Player", blue, v -> playerForm());
            addBtn("Back", panel2, v -> home());
            return;
        }
        try {
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                LinearLayout box = cardBox();
                String ph = p.optString("photo", "");
                if (ph.length() > 0) {
                    ImageView iv = new ImageView(this);
                    iv.setImageURI(Uri.parse(ph));
                    iv.setAdjustViewBounds(true);
                    iv.setMaxHeight(220);
                    box.addView(iv);
                }
                box.addView(tv("ID " + p.optString("pid", "--") + " • " + p.optString("name"), 20, gold));
                box.addView(tv(cleanRole(p.optString("role")) + " | " + p.optString("place") + " | " + p.optString("status", "NEW"), 14, text));
                box.addView(tv("Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 14, muted));
                final int idx = i;
                Button edit = btn("Edit Player", blue);
                edit.setOnClickListener(v -> editPlayerForm(idx));
                box.addView(edit);
                Button del = btn("Delete Player", red);
                del.setOnClickListener(v -> confirmDeletePlayer(idx));
                box.addView(del);
            }
        } catch (Exception e) { root.addView(tv(e.toString(), 14, red)); }
        addBtn("Back", panel2, v -> home());
    }

    void confirmDeletePlayer(int idx) {
        try {
            JSONObject p = players.getJSONObject(idx);
            if ("SOLD".equals(p.optString("status")) || "ICON".equals(p.optString("status"))) {
                new AlertDialog.Builder(this)
                        .setTitle("Delete player?")
                        .setMessage("This player is already " + p.optString("status") + ". Deleting will remove the player from the team/auction records.")
                        .setPositiveButton("Delete", (d,w) -> deletePlayer(idx))
                        .setNegativeButton("Cancel", null).show();
            } else {
                deletePlayer(idx);
            }
        } catch (Exception e) { toast(e.toString()); }
    }

    void deletePlayer(int idx) {
        try {
            JSONArray np = new JSONArray();
            for (int i = 0; i < players.length(); i++) if (i != idx) np.put(players.getJSONObject(i));
            players = np;
            ensurePlayerIds();
            deck = new JSONArray(); currentIndex = -1;
            save(); toast("Player deleted and IDs reassigned"); managePlayers();
        } catch (Exception e) { toast(e.toString()); }
    }

    void editPlayerForm(int idx) {
        try {
            JSONObject old = players.getJSONObject(idx);
            base("Edit Player");
            sp.edit().remove("last_photo").remove("last_id").apply();
            root.addView(tv("Player ID: " + old.optString("pid", "--"), 18, gold));
            String ph = old.optString("photo", "");
            if (ph.length() > 0) {
                ImageView iv = new ImageView(this);
                iv.setImageURI(Uri.parse(ph));
                iv.setAdjustViewBounds(true);
                iv.setMaxHeight(300);
                root.addView(iv);
            }
            root.addView(label("Player name")); EditText name = input("Player name"); name.setText(old.optString("name"));
            root.addView(label("Place")); EditText place = input("Place"); place.setText(old.optString("place"));
            root.addView(label("Mobile number")); EditText mobile = input("Mobile"); mobile.setInputType(InputType.TYPE_CLASS_PHONE); mobile.setText(old.optString("mobile"));
            root.addView(label("Player role")); Spinner role = spin(roles); role.setSelection(indexOf(roles, cleanRole(old.optString("role"))));
            root.addView(label("Batting style")); Spinner bat = spin(bats); bat.setSelection(indexOf(bats, old.optString("bat")));
            root.addView(label("Bowling style")); Spinner bowl = spin(bowls); bowl.setSelection(indexOf(bowls, old.optString("bowl")));
            CheckBox iconCb = new CheckBox(this); iconCb.setText("Icon player"); iconCb.setTextColor(text); iconCb.setChecked("ICON".equals(old.optString("status"))); root.addView(iconCb);
            root.addView(label("Icon / assigned team")); Spinner team = teamSpinner(true);
            for (int i = 0; i < team.getCount(); i++) if (team.getItemAtPosition(i).toString().equals(old.optString("team"))) team.setSelection(i);
            addBtn("Change Player Photo", blue, v -> { pickTarget = "photo"; pickImage(); });
            addBtn("Change Aadhaar / ID Photo", orange, v -> { pickTarget = "id"; pickImage(); });
            addBtn("Save Player Changes", green, v -> {
                try {
                    if (safeText(name).length() == 0) { toast("Enter player name"); return; }
                    old.put("name", safeText(name));
                    old.put("place", safeText(place));
                    old.put("mobile", safeText(mobile));
                    old.put("role", role.getSelectedItem().toString());
                    old.put("bat", bat.getSelectedItem().toString());
                    old.put("bowl", bowl.getSelectedItem().toString());
                    String newPhoto = sp.getString("last_photo", "");
                    String newId = sp.getString("last_id", "");
                    if (newPhoto.length() > 0) old.put("photo", newPhoto);
                    if (newId.length() > 0) old.put("idp", newId);
                    if (iconCb.isChecked()) {
                        String tn = team.getSelectedItem() == null ? "" : team.getSelectedItem().toString();
                        if (tn.length() == 0 || tn.startsWith("No ")) { toast("Select team for icon player"); return; }
                        for (int i=0;i<players.length();i++) {
                            if (i == idx) continue;
                            JSONObject p2 = players.getJSONObject(i);
                            if (tn.equals(p2.optString("team")) && "ICON".equals(p2.optString("status"))) { p2.put("status", "NEW"); p2.put("team", ""); p2.put("bid", 0); }
                        }
                        old.put("status", "ICON"); old.put("team", tn); old.put("bid", 0);
                    } else if ("ICON".equals(old.optString("status"))) {
                        old.put("status", "NEW"); old.put("team", ""); old.put("bid", 0);
                    }
                    sp.edit().remove("last_photo").remove("last_id").apply();
                    deck = new JSONArray(); currentIndex = -1; save(); toast("Player updated"); managePlayers();
                } catch (Exception e) { toast(e.toString()); }
            });
            addBtn("Back", panel2, v -> managePlayers());
        } catch (Exception e) { toast(e.toString()); }
    }

    void playerForm() {
        base("Add Player");
        root.addView(label("Player name"));
        EditText name = input("Example: Sanju Samson");
        root.addView(label("Place"));
        EditText place = input("Example: Thrissur");
        root.addView(label("Mobile number"));
        EditText mobile = input("Example: 9876543210");
        mobile.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(label("Player role"));
        Spinner role = spin(roles);
        root.addView(label("Batting style"));
        Spinner bat = spin(bats);
        root.addView(label("Bowling style"));
        Spinner bowl = spin(bowls);
        CheckBox iconCb = new CheckBox(this);
        iconCb.setText("Mark as Icon Player - directly assign to a team, not auctioned");
        iconCb.setTextColor(text);
        iconCb.setPadding(8, 8, 8, 8);
        root.addView(iconCb);
        root.addView(label("Icon player team"));
        Spinner iconTeam = iconAvailableTeamSpinner(true);
        addBtn("Upload Player Photo", blue, v -> { pickTarget = "photo"; pickImage(); });
        addBtn("Upload Aadhaar / ID Photo", orange, v -> { pickTarget = "id"; pickImage(); });
        addBtn("Save Player", green, v -> {
            try {
                if (name.getText().toString().trim().length() == 0) { toast("Enter player name"); return; }
                ensurePlayerIds();
                JSONObject o = new JSONObject();
                o.put("pid", nextPlayerId());
                o.put("name", name.getText().toString().trim());
                o.put("place", place.getText().toString().trim());
                o.put("mobile", mobile.getText().toString().trim());
                o.put("role", role.getSelectedItem().toString());
                o.put("bat", bat.getSelectedItem().toString());
                o.put("bowl", bowl.getSelectedItem().toString());
                o.put("photo", sp.getString("last_photo", ""));
                o.put("idp", sp.getString("last_id", ""));
                if (iconCb.isChecked()) {
                    String it = iconTeam.getSelectedItem() == null ? "" : iconTeam.getSelectedItem().toString();
                    if (it.length() == 0 || "No teams added".equals(it) || "All teams already have icon player".equals(it)) { toast("No available team for new icon. Use Change Icon Player to replace an existing icon."); return; }
                    o.put("status", "ICON");
                    o.put("team", it);
                    o.put("bid", 0);
                } else {
                    o.put("status", "NEW");
                    o.put("team", "");
                    o.put("bid", 0);
                }
                players.put(o);
                sp.edit().remove("last_photo").remove("last_id").apply();
                save();
                toast("Player saved");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    void teamForm() {
        base("Add Franchisee / Team");
        root.addView(label("Team / franchisee name"));
        EditText n = input("Example: RDB");
        addBtn("Upload Team Logo", blue, v -> { pickTarget = "teamLogo"; pickImage(); });
        addBtn("Save Team", green, v -> {
            try {
                if (n.getText().toString().trim().length() == 0) { toast("Enter team name"); return; }
                JSONObject o = new JSONObject();
                o.put("name", n.getText().toString().trim());
                o.put("logo", sp.getString("last_team_logo", ""));
                o.put("pool", "Pool A");
                teams.put(o);
                sp.edit().remove("last_team_logo").apply();
                save();
                toast("Team saved");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    int teamCount(String t) throws Exception {
        int c = 0;
        for (int i = 0; i < players.length(); i++) if (t.equals(players.getJSONObject(i).optString("team"))) c++;
        return c;
    }

    int teamSpent(String t) throws Exception {
        int spent = 0;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.getJSONObject(i);
            if (t.equals(p.optString("team"))) spent += p.optInt("bid", 0);
        }
        return spent;
    }

    int teamBalance(String t) throws Exception { return maxBucket() - teamSpent(t); }

    int maxBidForTeam(String t) throws Exception {
        int bought = teamCount(t);
        int slots = totalSlots();
        if (bought >= slots) return 0;
        int balance = teamBalance(t);
        int reserveAfterCurrentBuy = (slots - bought - 1) * basePoints();
        int maxBid = balance - reserveAfterCurrentBuy;
        return Math.max(0, maxBid);
    }

    int nextIncrementFor(int bid) {
        String cfg = sp.getString("increments", "300-999:50\n1000-2999:100\n3000-99999:250");
        String[] lines = cfg.split("\\n");
        for (String line : lines) {
            try {
                line = line.trim();
                if (line.length() == 0 || !line.contains(":")) continue;
                String[] lrInc = line.split(":");
                String[] lr = lrInc[0].split("-");
                int low = Integer.parseInt(lr[0].trim());
                int high = Integer.parseInt(lr[1].trim());
                int inc = Integer.parseInt(lrInc[1].trim());
                if (bid >= low && bid <= high) return inc;
            } catch (Exception e) { }
        }
        return 100;
    }

    void showTeamPoints() {
        try {
            LinearLayout box = cardBox();
            box.addView(tv("Live Bucket Table", 20, gold));
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            TableLayout table = new TableLayout(this);
            table.setStretchAllColumns(true);
            table.addView(row(new String[]{"TEAM", "SQUAD", "SPENT", "BALANCE", "MAX BID", "NEXT INC"}, true));
            for (int i = 0; i < teams.length(); i++) {
                String tn = teams.getJSONObject(i).optString("name");
                int mb = maxBidForTeam(tn);
                table.addView(row(new String[]{tn, teamCount(tn)+"/"+totalSlots(), String.valueOf(teamSpent(tn)), String.valueOf(teamBalance(tn)), String.valueOf(mb), String.valueOf(nextIncrementFor(Math.max(basePoints(), mb)))}, false));
            }
            hsv.addView(table);
            box.addView(hsv);
        } catch (Exception e) { }
    }

    TableRow row(String[] vals, boolean header) {
        TableRow tr = new TableRow(this);
        tr.setBackgroundColor(header ? Color.rgb(76, 55, 10) : panel2);
        for (String v : vals) {
            TextView cell = tv(v, header ? 13 : 14, header ? gold : text);
            cell.setTypeface(Typeface.DEFAULT_BOLD);
            cell.setPadding(18, 14, 18, 14);
            tr.addView(cell);
        }
        return tr;
    }

    void newRound() {
        try {
            ArrayList<Integer> ids = new ArrayList<Integer>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                String st = p.optString("status", "NEW");
                if ("SOLD".equals(st)) continue;
                if (roundNo == 0 && "NEW".equals(st)) ids.add(i);
                else if (roundNo > 0 && ("UNSOLD".equals(st) || "RECALL".equals(st))) ids.add(i);
            }
            if (ids.size() == 0 && roundNo == 0) {
                for (int i = 0; i < players.length(); i++) if (!"SOLD".equals(players.getJSONObject(i).optString("status"))) ids.add(i);
            }
            Collections.shuffle(ids);
            deck = new JSONArray();
            for (int x : ids) deck.put(x);
            currentIndex = ids.size() == 0 ? -1 : 0;
            if (ids.size() > 0) roundNo++;
            auctionEnded = false;
            save();
        } catch (Exception e) { }
    }

    ArrayList<String> availableTeams() throws Exception {
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < teams.length(); i++) {
            String tn = teams.getJSONObject(i).optString("name");
            if (teamCount(tn) < totalSlots()) names.add(tn);
        }
        return names;
    }

    void auction() {
        base("Auction Room");
        showTeamPoints();
        if (auctionEnded) {
            root.addView(tv("Auction ended manually. You can export PDF or reset auction status from Settings.", 18, gold));
            addBtn("Export All Teams PDF", green, v -> exportPdf());
        addBtn("Export Selected Team PDF", blue, v -> exportTeamPdfScreen());
            addBtn("Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (players.length() == 0 || teams.length() == 0) {
            root.addView(tv("Add players and franchisees first.", 18, text));
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (allSoldOrFull()) {
            root.addView(tv("Auction completed or all teams are full.", 20, green));
            addBtn("Teams & Players", blue, v -> teamsView());
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (deck.length() == 0 || currentIndex < 0 || currentIndex >= deck.length()) {
            LinearLayout info = cardBox();
            info.addView(tv(roundNo == 0 ? "Start First Round" : "Start Next Unsold/Recall Round", 22, gold));
            info.addView(tv("Round rules: First round displays every NEW player once in random order. Next rounds use only UNSOLD + RECALL players, randomly once each. SOLD players never return.", 15, text));
            addBtn(roundNo == 0 ? "Start First Random Round" : "Start Next Round", green, v -> { newRound(); auction(); });
            addBtn("End Auction", red, v -> { auctionEnded = true; save(); home(); });
            addBtn("Back", panel2, v -> home());
            return;
        }
        try {
            int pi = deck.getInt(currentIndex);
            JSONObject p = players.getJSONObject(pi);
            LinearLayout box = cardBox();
            box.addView(tv("Auction Card " + (currentIndex + 1) + " / " + deck.length(), 15, gold));
            ImageView iv = new ImageView(this);
            String ph = p.optString("photo", "");
            if (ph.length() > 0) iv.setImageURI(Uri.parse(ph));
            else iv.setBackgroundColor(panel2);
            iv.setAdjustViewBounds(true);
            iv.setMaxHeight(560);
            box.addView(iv, new LinearLayout.LayoutParams(-1, -2));
            TextView idBadge = playerIdBadge(p.optString("pid", "--"));
            box.addView(idBadge);
            TextView playerName = tv(p.optString("name"), 30, text);
            playerName.setTypeface(Typeface.DEFAULT_BOLD);
            playerName.setGravity(Gravity.CENTER);
            box.addView(playerName);
            TextView detailText = tv("Role: " + cleanRole(p.optString("role")) + "\nBatting: " + p.optString("bat") + "\nBowling: " + p.optString("bowl") + "\nBase Points: " + basePoints(), 16, Color.LTGRAY);
            detailText.setGravity(Gravity.CENTER);
            box.addView(detailText);

            root.addView(label("Sold to team"));
            ArrayList<String> ok = availableTeams();
            Spinner ts = new Spinner(this);
            ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ok) { public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; } public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }};
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            ts.setAdapter(ad);
            root.addView(ts);

            root.addView(label("Sold bid value / bucket points"));
            EditText bid = input("Enter final bid points");
            bid.setInputType(InputType.TYPE_CLASS_NUMBER);
            bid.setText(String.valueOf(basePoints()));

            TextView hint = tv("Select a team to view max bid.", 14, Color.LTGRAY);
            root.addView(hint);
            ts.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                public void onItemSelected(android.widget.AdapterView<?> parent, View view, int pos, long id) {
                    try {
                        String tn = parent.getItemAtPosition(pos).toString();
                        int mb = maxBidForTeam(tn);
                        hint.setText(tn + " can bid up to " + mb + ". Increment at current bid: " + nextIncrementFor(toInt(bid.getText().toString(), basePoints())));
                    } catch (Exception e) { }
                }
                public void onNothingSelected(android.widget.AdapterView<?> parent) { }
            });

            addBtn("SOLD - Add to Selected Team", green, v -> {
                try {
                    if (ts.getCount() == 0) { toast("All teams are full"); return; }
                    String tn = ts.getSelectedItem().toString();
                    int val = toInt(bid.getText().toString(), 0);
                    if (val < basePoints()) { toast("Bid cannot be below base points"); return; }
                    int max = maxBidForTeam(tn);
                    if (val > max) { toast("Bid exceeds max allowed for " + tn + ": " + max); return; }
                    JSONObject pp = players.getJSONObject(pi);
                    pp.put("status", "SOLD");
                    pp.put("team", tn);
                    pp.put("bid", val);
                    next();
                } catch (Exception e) { toast(e.toString()); }
            });
            addBtn("UNSOLD - Move to Unsold Bucket", red, v -> mark(pi, "UNSOLD"));
            addBtn("RECALL - Move to Recall Bucket", orange, v -> mark(pi, "RECALL"));
            addBtn("End Auction", red, v -> { auctionEnded = true; save(); home(); });
            addBtn("Back", panel2, v -> home());
        } catch (Exception e) {
            root.addView(tv(e.toString(), 14, red));
        }
    }

    int toInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    boolean allSoldOrFull() {
        try {
            boolean anyUnsold = false;
            for (int i = 0; i < players.length(); i++) { String st = players.getJSONObject(i).optString("status"); if (!"SOLD".equals(st) && !"ICON".equals(st)) anyUnsold = true; }
            if (!anyUnsold) return true;
            boolean anyTeamSlot = false;
            for (int i = 0; i < teams.length(); i++) if (teamCount(teams.getJSONObject(i).optString("name")) < totalSlots()) anyTeamSlot = true;
            return !anyTeamSlot;
        } catch (Exception e) { return false; }
    }

    void mark(int i, String s) {
        try {
            players.getJSONObject(i).put("status", s);
            players.getJSONObject(i).put("team", "");
            players.getJSONObject(i).put("bid", 0);
            next();
        } catch (Exception e) { }
    }

    void next() {
        currentIndex++;
        save();
        if (currentIndex >= deck.length()) {
            deck = new JSONArray();
            currentIndex = -1;
            save();
            toast("Round completed");
        }
        auction();
    }

    void teamsView() {
        base("Teams & Squads");
        try {
            root.addView(tv("Squad slots: " + totalSlots() + " | Max bucket: " + maxBucket() + " | Base: " + basePoints(), 15, gold));
            for (int t = 0; t < teams.length(); t++) {
                JSONObject team = teams.getJSONObject(t);
                String tn = team.optString("name");
                LinearLayout box = cardBox();
                String logo = team.optString("logo", "");
                if (logo.length() > 0) {
                    ImageView iv = new ImageView(this);
                    iv.setImageURI(Uri.parse(logo));
                    iv.setAdjustViewBounds(true);
                    iv.setMaxHeight(220);
                    box.addView(iv);
                }
                box.addView(tv(tn + "  (" + teamCount(tn) + "/" + totalSlots() + ")", 22, gold));
                box.addView(tv("Spent: " + teamSpent(tn) + " | Balance: " + teamBalance(tn) + " | Max Bid: " + maxBidForTeam(tn), 14, text));
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (tn.equals(p.optString("team"))) { String tag = "ICON".equals(p.optString("status")) ? " 👑 ICON" : ""; box.addView(tv("• " + p.optString("name") + tag + " - " + cleanRole(p.optString("role")) + " - " + p.optInt("bid") + " pts", 15, Color.LTGRAY)); }
                }
                final int editIndex = t;
                Button eb = btn("Edit Team Name / Logo", blue);
                eb.setOnClickListener(v -> editTeamForm(editIndex));
                box.addView(eb);
                final int delIndex = t;
                Button db = btn("Delete " + tn, red);
                db.setOnClickListener(v -> confirmDeleteTeam(delIndex));
                box.addView(db);
            }
        } catch (Exception e) { root.addView(tv(e.toString(), 14, red)); }
        addBtn("Export All Teams PDF", green, v -> exportPdf());
        addBtn("Export Selected Team PDF", blue, v -> exportTeamPdfScreen());
        addBtn("Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
        addBtn("Back", panel2, v -> home());
    }


    void editTeamForm(int idx) {
        try {
            JSONObject tm = teams.getJSONObject(idx);
            String oldName = tm.optString("name");
            base("Edit Team / Franchisee");
            sp.edit().remove("last_team_logo").apply();
            String logo = tm.optString("logo", "");
            if (logo.length() > 0) {
                ImageView iv = new ImageView(this);
                iv.setImageURI(Uri.parse(logo));
                iv.setAdjustViewBounds(true);
                iv.setMaxHeight(280);
                root.addView(iv);
            }
            root.addView(label("Team / franchisee name"));
            EditText n = input("Team name"); n.setText(oldName);
            addBtn("Change Team Logo", blue, v -> { pickTarget = "teamLogo"; pickImage(); });
            addBtn("Save Team Changes", green, v -> {
                try {
                    String newName = safeText(n);
                    if (newName.length() == 0) { toast("Enter team name"); return; }
                    for (int i = 0; i < teams.length(); i++) {
                        if (i != idx && newName.equalsIgnoreCase(teams.getJSONObject(i).optString("name"))) { toast("Team name already exists"); return; }
                    }
                    tm.put("name", newName);
                    String newLogo = sp.getString("last_team_logo", "");
                    if (newLogo.length() > 0) tm.put("logo", newLogo);
                    if (!oldName.equals(newName)) {
                        for (int i = 0; i < players.length(); i++) {
                            JSONObject p = players.getJSONObject(i);
                            if (oldName.equals(p.optString("team"))) p.put("team", newName);
                        }
                        for (int i = 0; i < fixtures.length(); i++) {
                            JSONObject f = fixtures.getJSONObject(i);
                            if (oldName.equals(f.optString("a"))) f.put("a", newName);
                            if (oldName.equals(f.optString("b"))) f.put("b", newName);
                        }
                    }
                    sp.edit().remove("last_team_logo").apply();
                    save(); toast("Team updated"); teamsView();
                } catch (Exception e) { toast(e.toString()); }
            });
            addBtn("Back", panel2, v -> teamsView());
        } catch (Exception e) { toast(e.toString()); }
    }

    void confirmDeleteTeam(int idx) {
        try {
            String tn = teams.getJSONObject(idx).optString("name");
            new AlertDialog.Builder(this).setTitle("Delete team?").setMessage("Delete " + tn + "? Sold players in this team will be moved to RECALL bucket and their bid will be cleared.")
                    .setPositiveButton("Delete", (d,w) -> deleteTeam(idx))
                    .setNegativeButton("Cancel", null).show();
        } catch (Exception e) { toast(e.toString()); }
    }

    void deleteTeam(int idx) {
        try {
            String tn = teams.getJSONObject(idx).optString("name");
            JSONArray nt = new JSONArray();
            for (int i = 0; i < teams.length(); i++) if (i != idx) nt.put(teams.getJSONObject(i));
            teams = nt;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if (tn.equals(p.optString("team"))) { p.put("team", ""); p.put("bid", 0); p.put("status", "RECALL"); }
            }
            deck = new JSONArray(); currentIndex = -1; save(); toast("Team deleted"); teamsView();
        } catch (Exception e) { toast(e.toString()); }
    }

    void buckets() {
        base("Unsold / Recall Buckets");
        try {
            LinearLayout u = cardBox();
            u.addView(tv("UNSOLD", 22, red));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if ("UNSOLD".equals(p.optString("status"))) u.addView(tv("• " + p.optString("name") + " | " + p.optString("role") + " | Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 15, text));
            }
            LinearLayout r = cardBox();
            r.addView(tv("RECALL", 22, orange));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if ("RECALL".equals(p.optString("status"))) r.addView(tv("• " + p.optString("name") + " | " + p.optString("role") + " | Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 15, text));
            }
        } catch (Exception e) { }
        addBtn("Back", panel2, v -> home());
    }


    Spinner playerSpinner(boolean includeAll) {
        ArrayList<String> list = new ArrayList<String>();
        try { for (int i = 0; i < players.length(); i++) list.add(players.getJSONObject(i).optString("name")); } catch (Exception e) { }
        if (list.size() == 0) list.add("No players added");
        return customSpinner(list);
    }

    Spinner customSpinner(ArrayList<String> list) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {
            public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; }
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    void changeIconScreen() {
        base("Change Icon Player");
        if (players.length() == 0 || teams.length() == 0) { root.addView(tv("Add players and teams first.", 18, text)); addBtn("Back", panel2, v -> home()); return; }
        LinearLayout info = cardBox();
        info.addView(tv("Icon players are directly assigned to a franchise, excluded from auction rounds, and counted in squad size/max bid reserve.", 15, text));
        root.addView(label("Select player"));
        Spinner ps = playerSpinner(true);
        root.addView(label("Assign as icon to team"));
        Spinner ts = teamSpinner(false);
        addBtn("Set / Change Icon", green, v -> {
            try {
                String pn = ps.getSelectedItem() == null ? "" : ps.getSelectedItem().toString();
                String tn = ts.getSelectedItem() == null ? "" : ts.getSelectedItem().toString();
                if (pn.startsWith("No ") || tn.length()==0) { toast("Select valid player/team"); return; }
                for (int i=0;i<players.length();i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (tn.equals(p.optString("team")) && "ICON".equals(p.optString("status"))) { p.put("status", "NEW"); p.put("team", ""); p.put("bid", 0); }
                }
                for (int i=0;i<players.length();i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (pn.equals(p.optString("name"))) { p.put("status", "ICON"); p.put("team", tn); p.put("bid", 0); }
                }
                deck = new JSONArray(); currentIndex = -1; save(); toast("Icon player updated"); home();
            } catch(Exception e) { toast(e.toString()); }
        });
        addBtn("Remove All Icons", red, v -> { try { for(int i=0;i<players.length();i++){ JSONObject p=players.getJSONObject(i); if("ICON".equals(p.optString("status"))){ p.put("status","NEW"); p.put("team",""); p.put("bid",0); } } deck=new JSONArray(); currentIndex=-1; save(); toast("Icons removed"); home(); } catch(Exception e){toast(e.toString());} });
        addBtn("Back", panel2, v -> home());
    }

    String poolName(int i) { return "Pool " + (char)('A' + i); }

    Spinner poolSpinner(String selected, int count) {
        ArrayList<String> list = new ArrayList<String>();
        for (int i=0;i<count;i++) list.add(poolName(i));
        Spinner s = customSpinner(list);
        for (int i=0;i<list.size();i++) if (list.get(i).equals(selected)) s.setSelection(i);
        return s;
    }

    void fixturesSetup() {
        base("Pools & Fixtures");
        int pc = Math.max(1, sp.getInt("poolCount", 2));
        LinearLayout guide = cardBox();
        guide.addView(tv("Create pools, assign each franchise to one pool only, then generate pool matches and knockout placeholders. Export fixtures as a styled PDF.", 15, text));
        root.addView(label("Number of pools"));
        EditText pcInput = input("2"); pcInput.setInputType(InputType.TYPE_CLASS_NUMBER); pcInput.setText(String.valueOf(pc));
        addBtn("Apply Pool Count", blue, v -> { sp.edit().putInt("poolCount", Math.max(1, toInt(pcInput.getText().toString(), 2))).apply(); fixturesSetup(); });

        final ArrayList<Spinner> poolSpinners = new ArrayList<Spinner>();
        for (int i=0;i<teams.length();i++) {
            try {
                JSONObject tm = teams.getJSONObject(i);
                root.addView(label(tm.optString("name") + " pool"));
                poolSpinners.add(poolSpinner(tm.optString("pool", "Pool A"), pc));
            } catch(Exception e) { }
        }
        CheckBox cross = new CheckBox(this); cross.setText("Cross-pool league: teams play against teams from other pools"); cross.setTextColor(text); cross.setChecked(sp.getBoolean("crossPool", true)); root.addView(cross);
        CheckBox ipl = new CheckBox(this); ipl.setText("IPL style full league: every team plays every other team"); ipl.setTextColor(text); ipl.setChecked(sp.getBoolean("iplStyle", false)); root.addView(ipl);
        root.addView(label("Start time HH:mm")); EditText start = input("08:00"); start.setText(sp.getString("fixtureStart", "08:00"));
        root.addView(label("Minutes for one match")); EditText dur = input("30"); dur.setInputType(InputType.TYPE_CLASS_NUMBER); dur.setText(String.valueOf(sp.getInt("matchMinutes", 30)));
        root.addView(label("Gap between matches in minutes")); EditText gap = input("10"); gap.setInputType(InputType.TYPE_CLASS_NUMBER); gap.setText(String.valueOf(sp.getInt("gapMinutes", 10)));
        root.addView(label("Qualifiers from each pool")); EditText qual = input("2"); qual.setInputType(InputType.TYPE_CLASS_NUMBER); qual.setText(String.valueOf(sp.getInt("qualifiers", 2)));
        CheckBox qf = new CheckBox(this); qf.setText("Include Quarter Finals if qualifiers are more than 4"); qf.setTextColor(text); qf.setChecked(sp.getBoolean("includeQF", true)); root.addView(qf);
        CheckBox semi = new CheckBox(this); semi.setText("Include Semi Finals"); semi.setTextColor(text); semi.setChecked(sp.getBoolean("includeSemi", true)); root.addView(semi);
        CheckBox fin = new CheckBox(this); fin.setText("Include Final"); fin.setTextColor(text); fin.setChecked(sp.getBoolean("includeFinal", true)); root.addView(fin);
        CheckBox losers = new CheckBox(this); losers.setText("Include Losers Final / 3rd Place Match"); losers.setTextColor(text); losers.setChecked(sp.getBoolean("includeLosers", false)); root.addView(losers);
        addBtn("Save Pools & Generate Fixtures", green, v -> {
            try {
                for (int i=0;i<teams.length();i++) teams.getJSONObject(i).put("pool", poolSpinners.get(i).getSelectedItem().toString());
                sp.edit().putInt("poolCount", Math.max(1,toInt(pcInput.getText().toString(),2))).putBoolean("crossPool", cross.isChecked()).putBoolean("iplStyle", ipl.isChecked()).putString("fixtureStart", start.getText().toString().trim()).putInt("matchMinutes", Math.max(1,toInt(dur.getText().toString(),30))).putInt("gapMinutes", Math.max(0,toInt(gap.getText().toString(),10))).putInt("qualifiers", Math.max(1,toInt(qual.getText().toString(),2))).putBoolean("includeQF", qf.isChecked()).putBoolean("includeSemi", semi.isChecked()).putBoolean("includeFinal", fin.isChecked()).putBoolean("includeLosers", losers.isChecked()).apply();
                generateFixtures(cross.isChecked(), ipl.isChecked(), sp.getInt("poolCount",2), sp.getString("fixtureStart","08:00"), sp.getInt("matchMinutes",30), sp.getInt("gapMinutes",10), sp.getInt("qualifiers",2), qf.isChecked(), semi.isChecked(), fin.isChecked(), losers.isChecked());
                save(); toast("Fixtures generated"); fixturesView();
            } catch(Exception e) { toast(e.toString()); }
        });
        addBtn("View Fixtures", blue, v -> fixturesView());
        addBtn("Export Fixtures PDF", orange, v -> exportFixturesPdf());
        addBtn("Back", panel2, v -> home());
    }

    int parseTime(String hhmm) {
        try { String[] p = hhmm.split(":"); return Integer.parseInt(p[0].trim())*60 + Integer.parseInt(p[1].trim()); } catch(Exception e) { return 8*60; }
    }
    String fmtTime(int mins) { int h=(mins/60)%24; int m=mins%60; return (h<10?"0":"")+h+":"+(m<10?"0":"")+m; }



    void addPendingFixture(ArrayList<JSONObject> pending, String round, String a, String b) throws Exception {
        JSONObject f = new JSONObject();
        f.put("round", round); f.put("teamA", a); f.put("teamB", b);
        pending.add(f);
    }

    boolean hasTeam(JSONObject f, String a, String b) {
        String ta = f.optString("teamA");
        String tb = f.optString("teamB");
        return ta.equals(a) || ta.equals(b) || tb.equals(a) || tb.equals(b);
    }

    void schedulePendingFixtures(ArrayList<JSONObject> pending, int[] clock, int matchMin, int gapMin) throws Exception {
        String lastA = "", lastB = "";
        while (!pending.isEmpty()) {
            int chosen = -1;
            for (int i = 0; i < pending.size(); i++) {
                if (!hasTeam(pending.get(i), lastA, lastB)) { chosen = i; break; }
            }
            if (chosen < 0) chosen = 0; // unavoidable when teams/matches are limited
            JSONObject f = pending.remove(chosen);
            addFixture(f.optString("round"), f.optString("teamA"), f.optString("teamB"), clock, matchMin, gapMin);
            lastA = f.optString("teamA");
            lastB = f.optString("teamB");
        }
    }

    void addFixture(String round, String a, String b, int[] clock, int matchMin, int gapMin) throws Exception {
        JSONObject f = new JSONObject();
        f.put("round", round); f.put("teamA", a); f.put("teamB", b); f.put("time", fmtTime(clock[0]));
        fixtures.put(f); clock[0] += matchMin + gapMin;
    }

    void generateFixtures(boolean cross, boolean ipl, int poolCount, String start, int matchMin, int gapMin, int qualifiers, boolean qf, boolean semi, boolean fin, boolean losers) throws Exception {
        fixtures = new JSONArray(); int[] clock = new int[]{parseTime(start)};
        ArrayList<JSONObject> leagueMatches = new ArrayList<JSONObject>();
        ArrayList<String> all = new ArrayList<String>();
        for (int i=0;i<teams.length();i++) all.add(teams.getJSONObject(i).optString("name"));
        if (ipl) {
            for (int i=0;i<all.size();i++) for (int j=i+1;j<all.size();j++) addPendingFixture(leagueMatches, "IPL League", all.get(i), all.get(j));
        } else if (cross) {
            for (int i=0;i<teams.length();i++) for (int j=i+1;j<teams.length();j++) {
                JSONObject a=teams.getJSONObject(i), b=teams.getJSONObject(j);
                if (!a.optString("pool").equals(b.optString("pool"))) addPendingFixture(leagueMatches, "Cross Pool", a.optString("name"), b.optString("name"));
            }
        } else {
            for (int p=0;p<poolCount;p++) {
                String pn=poolName(p); ArrayList<String> list=new ArrayList<String>();
                for (int i=0;i<teams.length();i++) if(pn.equals(teams.getJSONObject(i).optString("pool"))) list.add(teams.getJSONObject(i).optString("name"));
                for (int i=0;i<list.size();i++) for (int j=i+1;j<list.size();j++) addPendingFixture(leagueMatches, pn + " League", list.get(i), list.get(j));
            }
        }
        schedulePendingFixtures(leagueMatches, clock, matchMin, gapMin);
        int totalQual = Math.max(2, poolCount * qualifiers);
        ArrayList<String> q = new ArrayList<String>();
        for(int p=0;p<poolCount;p++) for(int r=1;r<=qualifiers;r++) q.add(poolName(p) + " #" + r);
        while(q.size()<totalQual) q.add("Qualifier " + (q.size()+1));
        if (qf && totalQual > 4) {
            int pairs = Math.min(4, totalQual/2);
            for(int i=0;i<pairs;i++) addFixture("Quarter Final", q.get(i), q.get(totalQual-1-i), clock, matchMin, gapMin);
            q.clear(); for(int i=1;i<=pairs;i++) q.add("QF"+i+" Winner");
        }
        if (semi && q.size() >= 4) { addFixture("Semi Final 1", q.get(0), q.get(3), clock, matchMin, gapMin); addFixture("Semi Final 2", q.get(1), q.get(2), clock, matchMin, gapMin); q.clear(); q.add("SF1 Winner"); q.add("SF2 Winner"); }
        if (losers) addFixture("Losers Final", "SF1 Loser", "SF2 Loser", clock, matchMin, gapMin);
        if (fin) addFixture("Final", q.size()>=2?q.get(0):"Finalist 1", q.size()>=2?q.get(1):"Finalist 2", clock, matchMin, gapMin);
    }

    void fixturesView() {
        base("Fixtures");
        if (fixtures.length()==0) { root.addView(tv("No fixtures generated yet.", 18, text)); addBtn("Setup Fixtures", green, v -> fixturesSetup()); addBtn("Back", panel2, v -> home()); return; }
        LinearLayout box = cardBox(); box.addView(tv("🏟️ " + sp.getString("auctionName", "Tournament") + " Fixtures", 20, gold));
        try { for(int i=0;i<fixtures.length();i++){ JSONObject f=fixtures.getJSONObject(i); box.addView(tv((i+1)+". "+f.optString("time")+"  |  "+f.optString("round")+"  |  "+f.optString("teamA")+" vs "+f.optString("teamB"), 14, text)); } } catch(Exception e) {}
        addBtn("Export Fixtures PDF", orange, v -> exportFixturesPdf());
        addBtn("Back", panel2, v -> home());
    }

    void exportFixturesPdf() {
        pdfMode = "FIXTURES"; pdfTeam = "";
        try { Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/pdf"); i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Tournament").replace(" ", "_") + "_Fixtures.pdf"); startActivityForResult(i, 7); } catch(Exception e) { toast("PDF export not supported: " + e.toString()); }
    }

    void settings() {
        base("Auction Settings");
        root.addView(label("Auction / Tournament name"));
        EditText an = input("Example: KPL Season 1");
        an.setText(sp.getString("auctionName", "KPL Season 1"));
        root.addView(label("Main squad players per team"));
        EditText ppt = input("11");
        ppt.setInputType(InputType.TYPE_CLASS_NUMBER);
        ppt.setText(String.valueOf(sp.getInt("playersPerTeam", 11)));

        CheckBox cb = new CheckBox(this);
        cb.setText("Enable bench players");
        cb.setTextColor(text);
        cb.setChecked(sp.getBoolean("bench", false));
        root.addView(cb);

        root.addView(label("Bench count per team"));
        EditText bc = input("2");
        bc.setInputType(InputType.TYPE_CLASS_NUMBER);
        bc.setText(String.valueOf(sp.getInt("benchCount", 2)));

        root.addView(label("Maximum bucket points per team"));
        EditText max = input("11000");
        max.setInputType(InputType.TYPE_CLASS_NUMBER);
        max.setText(String.valueOf(maxBucket()));

        root.addView(label("Base points per player"));
        EditText base = input("300");
        base.setInputType(InputType.TYPE_CLASS_NUMBER);
        base.setText(String.valueOf(basePoints()));

        root.addView(label("Bid increment ranges: start-end:increment"));
        EditText inc = input("300-999:50\n1000-2999:100\n3000-99999:250");
        inc.setSingleLine(false);
        inc.setMinLines(3);
        inc.setText(sp.getString("increments", "300-999:50\n1000-2999:100\n3000-99999:250"));

        LinearLayout info = cardBox();
        info.addView(tv("🏆 Professional Auction Rules", 18, gold));
        info.addView(tv("Maximum bid = current balance - ((total slots - players already bought - 1) x base points). Example: 11000 - ((11 - 0 - 1) x 300) = 8000. Edge cases handled: full squads, bid below base, over-budget bid, deleted teams, reset rounds, sold players never returning, unsold/recall-only later rounds.", 14, text));

        addBtn("Save Settings", green, v -> {
            sp.edit()
                    .putInt("playersPerTeam", Math.max(1, toInt(ppt.getText().toString(), 11)))
                    .putBoolean("bench", cb.isChecked())
                    .putInt("benchCount", Math.max(0, toInt(bc.getText().toString(), 2)))
                    .putInt("maxBucket", Math.max(0, toInt(max.getText().toString(), 11000)))
                    .putInt("basePoints", Math.max(0, toInt(base.getText().toString(), 300)))
                    .putString("increments", inc.getText().toString())
                    .putString("auctionName", an.getText().toString().trim().length()==0 ? "RDB Auction Manager" : an.getText().toString().trim())
                    .apply();
            toast("Settings saved");
            home();
        });
        addBtn("Reset Auction Status Only", red, v -> {
            try {
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    p.put("status", "NEW");
                    p.put("team", "");
                    p.put("bid", 0);
                }
                deck = new JSONArray();
                currentIndex = -1;
                roundNo = 0;
                auctionEnded = false;
                save();
                toast("Auction reset");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Clear ALL Data - Players, Teams, Auction", red, v -> confirmClearAll());
        addBtn("Back", panel2, v -> home());
    }

    void confirmClearAll() {
        new AlertDialog.Builder(this).setTitle("Clear all data?").setMessage("This deletes all players, teams, photos links, auction rounds, bids, and buckets from this app.")
                .setPositiveButton("Clear All", (d,w) -> { players = new JSONArray(); teams = new JSONArray(); deck = new JSONArray(); fixtures = new JSONArray(); currentIndex=-1; roundNo=0; auctionEnded=false; save(); toast("All data cleared"); home(); })
                .setNegativeButton("Cancel", null).show();
    }

    void exportPdf() {
        pdfMode = "ALL";
        pdfTeam = "";
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Auction").replace(" ", "_") + "_Auction_Teams_List.pdf");
            startActivityForResult(i, 7);
        } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
    }


    void playerCatalogueSettings() {
        base("Player Catalogue PDF Settings");
        root.addView(tv("Select exactly what should appear in the player catalogue. The PDF engine will dynamically include/exclude every selected field and render each player as a premium cricket auction card.", 15, text));
        CheckBox photo = new CheckBox(this); photo.setText("Show player photo"); photo.setTextColor(text); photo.setChecked(sp.getBoolean("catPhoto", true)); root.addView(photo);
        CheckBox idPhoto = new CheckBox(this); idPhoto.setText("Show Aadhaar / ID photo if uploaded"); idPhoto.setTextColor(text); idPhoto.setChecked(sp.getBoolean("catIdPhoto", false)); root.addView(idPhoto);
        CheckBox playerId = new CheckBox(this); playerId.setText("Show player ID"); playerId.setTextColor(text); playerId.setChecked(sp.getBoolean("catPlayerId", true)); root.addView(playerId);
        CheckBox place = new CheckBox(this); place.setText("Show place"); place.setTextColor(text); place.setChecked(sp.getBoolean("catPlace", true)); root.addView(place);
        CheckBox role = new CheckBox(this); role.setText("Show role"); role.setTextColor(text); role.setChecked(sp.getBoolean("catRole", true)); root.addView(role);
        CheckBox bat = new CheckBox(this); bat.setText("Show batting style"); bat.setTextColor(text); bat.setChecked(sp.getBoolean("catBat", true)); root.addView(bat);
        CheckBox bowl = new CheckBox(this); bowl.setText("Show bowling style"); bowl.setTextColor(text); bowl.setChecked(sp.getBoolean("catBowl", true)); root.addView(bowl);
        CheckBox mobile = new CheckBox(this); mobile.setText("Show mobile number"); mobile.setTextColor(text); mobile.setChecked(sp.getBoolean("catMobile", true)); root.addView(mobile);
        CheckBox team = new CheckBox(this); team.setText("Show team / franchise"); team.setTextColor(text); team.setChecked(sp.getBoolean("catTeam", true)); root.addView(team);
        CheckBox status = new CheckBox(this); status.setText("Show auction status"); status.setTextColor(text); status.setChecked(sp.getBoolean("catStatus", true)); root.addView(status);
        CheckBox bid = new CheckBox(this); bid.setText("Show bid points"); bid.setTextColor(text); bid.setChecked(sp.getBoolean("catBid", true)); root.addView(bid);
        CheckBox iconFlag = new CheckBox(this); iconFlag.setText("Show icon player badge/status"); iconFlag.setTextColor(text); iconFlag.setChecked(sp.getBoolean("catIconFlag", true)); root.addView(iconFlag);
        CheckBox base = new CheckBox(this); base.setText("Show base points"); base.setTextColor(text); base.setChecked(sp.getBoolean("catBase", true)); root.addView(base);
        CheckBox excludeIcons = new CheckBox(this); excludeIcons.setText("Exclude icon players from catalogue export"); excludeIcons.setTextColor(text); excludeIcons.setChecked(sp.getBoolean("catExcludeIcons", false)); root.addView(excludeIcons);
        addBtn("Save Catalogue Settings", green, v -> {
            sp.edit()
                    .putBoolean("catPhoto", photo.isChecked())
                    .putBoolean("catIdPhoto", idPhoto.isChecked())
                    .putBoolean("catPlayerId", playerId.isChecked())
                    .putBoolean("catPlace", place.isChecked())
                    .putBoolean("catRole", role.isChecked())
                    .putBoolean("catBat", bat.isChecked())
                    .putBoolean("catBowl", bowl.isChecked())
                    .putBoolean("catMobile", mobile.isChecked())
                    .putBoolean("catTeam", team.isChecked())
                    .putBoolean("catStatus", status.isChecked())
                    .putBoolean("catBid", bid.isChecked())
                    .putBoolean("catIconFlag", iconFlag.isChecked())
                    .putBoolean("catBase", base.isChecked())
                    .putBoolean("catExcludeIcons", excludeIcons.isChecked())
                    .apply();
            toast("Catalogue PDF settings saved");
            home();
        });
        addBtn("Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
        addBtn("Back", panel2, v -> home());
    }

    void exportPlayerCataloguePdf() {
        pdfMode = "PLAYERS";
        pdfTeam = "";
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Tournament").replace(" ", "_") + "_Player_Catalogue.pdf");
            startActivityForResult(i, 7);
        } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
    }

    void exportTeamPdfScreen() {
        base("Export Separate Team PDF");
        if (teams.length() == 0) { root.addView(tv("Add teams first.", 18, text)); addBtn("Back", panel2, v -> home()); return; }
        root.addView(tv("Choose one franchise to export as a separate PDF. Icon player, if assigned, will be shown as a larger captain-style card.", 15, text));
        root.addView(label("Select Team"));
        Spinner s = teamSpinner(false);
        addBtn("Export Selected Team PDF", green, v -> {
            pdfMode = "TEAM";
            pdfTeam = s.getSelectedItem() == null ? "" : s.getSelectedItem().toString();
            try {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Auction").replace(" ", "_") + "_" + pdfTeam.replace(" ", "_") + ".pdf");
                startActivityForResult(i, 7);
            } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    void writePdf(Uri uri) {
        try {
            ensurePlayerIds();
            if ("FIXTURES".equals(pdfMode)) { writeFixturesPdf(uri); return; }
            if ("PLAYERS".equals(pdfMode)) { writePlayerCataloguePdf(uri); return; }
            PdfDocument pdf = new PdfDocument();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            int pageNo = 1;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, pageNo).create());
            Canvas c = page.getCanvas();
            int y = drawPdfHeader(c, paint, pdfMode.equals("TEAM") ? pdfTeam : "All Teams");
            for (int t = 0; t < teams.length(); t++) {
                JSONObject team = teams.getJSONObject(t); String tn = team.optString("name");
                if ("TEAM".equals(pdfMode) && !tn.equals(pdfTeam)) continue;
                if (y > 690) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c = page.getCanvas(); y = drawPdfHeader(c, paint, pdfMode.equals("TEAM") ? pdfTeam : "All Teams"); }
                y = drawTeamPdfBlock(c, paint, tn, y);
            }
            pdf.finishPage(page);
            OutputStream os = getContentResolver().openOutputStream(uri);
            pdf.writeTo(os); os.close(); pdf.close(); toast("PDF exported");
        } catch (Exception e) { toast("PDF failed: " + e.toString()); }
    }


    void writePlayerCataloguePdf(Uri uri) {
        try {
            ensurePlayerIds();
            PdfDocument pdf = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            String tournament = sp.getString("auctionName", "Tournament");
            boolean excludeIcons = sp.getBoolean("catExcludeIcons", false);
            ArrayList<JSONObject> exportPlayers = new ArrayList<>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject pl = players.getJSONObject(i);
                if (excludeIcons && "ICON".equals(pl.optString("status"))) continue;
                exportPlayers.add(pl);
            }
            if (exportPlayers.size() == 0) { toast("No players available for selected catalogue settings"); return; }
            for (int i = 0; i < exportPlayers.size(); i++) {
                JSONObject pl = exportPlayers.get(i);
                PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, i + 1).create());
                Canvas c = page.getCanvas();
                drawPlayerCataloguePage(c, p, pl, tournament, i + 1, exportPlayers.size());
                pdf.finishPage(page);
            }
            OutputStream os = getContentResolver().openOutputStream(uri);
            pdf.writeTo(os); os.close(); pdf.close();
            toast("Player catalogue PDF exported");
        } catch (Exception e) { toast("Player catalogue PDF failed: " + e.toString()); }
    }

    void drawPlayerCataloguePage(Canvas c, Paint p, JSONObject pl, String tournament, int pageNo, int total) throws Exception {
        boolean showPhoto = sp.getBoolean("catPhoto", true);
        boolean showIdPhoto = sp.getBoolean("catIdPhoto", false);
        boolean showPlayerId = sp.getBoolean("catPlayerId", true);
        boolean showPlace = sp.getBoolean("catPlace", true);
        boolean showRole = sp.getBoolean("catRole", true);
        boolean showBat = sp.getBoolean("catBat", true);
        boolean showBowl = sp.getBoolean("catBowl", true);
        boolean showMobile = sp.getBoolean("catMobile", true);
        boolean showTeam = sp.getBoolean("catTeam", true);
        boolean showStatus = sp.getBoolean("catStatus", true);
        boolean showBid = sp.getBoolean("catBid", true);
        boolean showIconFlag = sp.getBoolean("catIconFlag", true);
        boolean showBase = sp.getBoolean("catBase", true);

        String role = cleanRole(pl.optString("role"));
        int rolePrimary = roleColor(role);
        int roleDark = darker(rolePrimary);
        int roleLight = lighter(rolePrimary);
        String status = pl.optString("status", "NEW");
        String playerName = pl.optString("name", "PLAYER NAME").toUpperCase();

        p.setStyle(Paint.Style.FILL);
        p.setShader(new android.graphics.LinearGradient(0, 0, 595, 842,
                new int[]{Color.rgb(3, 5, 19), Color.rgb(6, 19, 51), Color.rgb(32, 8, 28), Color.rgb(2, 7, 18)},
                new float[]{0f, 0.35f, 0.68f, 1f}, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 595, 842, p); p.setShader(null);
        drawGodLevelStadium(c, p);

        // Top broadcast/auction header
        p.setShader(new android.graphics.LinearGradient(0, 0, 595, 0,
                new int[]{Color.rgb(116, 24, 42), roleDark, Color.rgb(244, 184, 62)}, null, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(24, 24, 571, 110), 28, 28, p); p.setShader(null);
        p.setColor(Color.argb(180, 0, 0, 0)); c.drawRoundRect(new RectF(34, 32, 561, 102), 20, 20, p);
        p.setFakeBoldText(true); p.setTextSize(24); p.setColor(Color.rgb(255, 216, 94));
        c.drawText("RDB AUCTION MANAGER", 48, 59, p);
        p.setTextSize(12); p.setColor(Color.WHITE); p.setFakeBoldText(false);
        c.drawText(cut(tournament + "  •  PREMIUM PLAYER CATALOGUE", 58), 49, 82, p);
        p.setTextSize(10); p.setColor(Color.rgb(214, 226, 245));
        c.drawText("PLAYER " + pageNo + " / " + total + "  •  Generated cricket-card PDF", 49, 98, p);

        // Main hero trading card
        RectF shadow = new RectF(42, 132, 565, 776);
        p.setColor(Color.argb(160, 0, 0, 0)); c.drawRoundRect(shadow, 38, 38, p);
        RectF card = new RectF(30, 120, 553, 764);
        p.setShader(new android.graphics.LinearGradient(30, 120, 553, 764,
                new int[]{Color.rgb(255, 217, 94), Color.rgb(122, 88, 22), rolePrimary, Color.rgb(255, 244, 198)},
                new float[]{0f, 0.18f, 0.72f, 1f}, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(card, 42, 42, p); p.setShader(null);
        RectF inner = new RectF(40, 130, 543, 754);
        p.setShader(new android.graphics.LinearGradient(40, 130, 543, 754,
                new int[]{Color.rgb(5, 13, 31), roleDark, Color.rgb(13, 26, 51), Color.rgb(5, 10, 24)},
                new float[]{0f, 0.30f, 0.72f, 1f}, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(inner, 34, 34, p); p.setShader(null);

        // Metallic card glows and geometric strips
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.rgb(255, 236, 160)); c.drawRoundRect(inner, 34, 34, p); p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(52, 255, 255, 255)); c.drawPath(diagonalPath(40, 130, 543, 292), p);
        p.setColor(Color.argb(58, 255, 216, 94)); c.drawPath(diagonalPath(40, 540, 543, 754), p);
        p.setColor(Color.argb(40, Color.red(roleLight), Color.green(roleLight), Color.blue(roleLight))); c.drawCircle(506, 183, 76, p);
        p.setColor(Color.argb(26, 255, 255, 255)); c.drawCircle(86, 710, 92, p);

        // Role ribbon / ID / status
        p.setShader(new android.graphics.LinearGradient(54, 150, 529, 150,
                new int[]{rolePrimary, roleDark, Color.rgb(255, 216, 94)}, null, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(54, 148, 529, 196), 24, 24, p); p.setShader(null);
        p.setFakeBoldText(true); p.setTextSize(13); p.setColor(Color.WHITE);
        String ribbon = "MEGA AUCTION PLAYER CARD";
        if ("ICON".equals(status)) ribbon = "ICON PLAYER • DIRECT FRANCHISE PICK";
        else if ("SOLD".equals(status)) ribbon = "SOLD PLAYER • AUCTION WINNER";
        c.drawText(cut(ribbon, 42), 74, 178, p);
        if (showPlayerId) {
            p.setColor(Color.rgb(255, 228, 108)); c.drawRoundRect(new RectF(425, 157, 512, 188), 14, 14, p);
            p.setColor(Color.rgb(4, 10, 22)); p.setTextSize(13); c.drawText(cut("#" + pl.optString("pid", "--"), 10), 447, 178, p);
        }

        // Trophy / cricket visual accents
        drawTrophyGlyph(c, p, 480, 225, 42);
        drawCricketBatBall(c, p, 84, 230);

        int photoTop = 216;
        int photoBottom = 408;
        if (showPhoto) {
            RectF photoFrame = new RectF(74, photoTop, 521, photoBottom + 8);
            p.setColor(Color.argb(150, 0, 0, 0)); c.drawRoundRect(new RectF(80, photoTop+6, 527, photoBottom+14), 28, 28, p);
            p.setColor(Color.rgb(2, 8, 20)); c.drawRoundRect(photoFrame, 28, 28, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.rgb(255, 216, 94)); c.drawRoundRect(photoFrame, 28, 28, p); p.setStyle(Paint.Style.FILL);
            drawPlayerPhoto(c, pl.optString("photo"), 90, photoTop + 15, 415, 169, p);
            p.setColor(Color.argb(68, 255, 216, 94)); c.drawRect(90, photoBottom - 20, 505, photoBottom - 13, p);
        } else {
            p.setColor(Color.argb(65, 255, 216, 94)); c.drawCircle(297, 304, 92, p);
            p.setColor(Color.argb(40, 255, 255, 255)); c.drawCircle(297, 304, 58, p);
            p.setFakeBoldText(true); p.setTextSize(18); p.setColor(Color.rgb(255,216,94)); c.drawText("RDB", 274, 309, p);
            photoBottom = 318;
        }

        // Name plate
        RectF namePlate = new RectF(60, photoBottom + 26, 535, photoBottom + 92);
        p.setShader(new android.graphics.LinearGradient(60, 0, 535, 0,
                new int[]{Color.rgb(255, 216, 94), Color.rgb(255, 245, 200), Color.rgb(255, 216, 94)}, null, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(namePlate, 22, 22, p); p.setShader(null);
        p.setFakeBoldText(true); p.setColor(Color.rgb(6, 13, 30)); p.setTextSize(playerName.length() > 21 ? 23 : 31);
        c.drawText(cut(playerName, 30), 80, photoBottom + 68, p);
        p.setColor(rolePrimary); c.drawRoundRect(new RectF(72, photoBottom + 102, 306, photoBottom + 134), 16, 16, p);
        p.setColor(Color.WHITE); p.setTextSize(12);
        c.drawText(showRole ? cut(role.toUpperCase(), 26) : "CRICKET PLAYER", 90, photoBottom + 124, p);
        if (showIconFlag && "ICON".equals(status)) {
            p.setColor(Color.rgb(255, 216, 94)); c.drawRoundRect(new RectF(325, photoBottom + 102, 520, photoBottom + 134), 16, 16, p);
            p.setColor(Color.rgb(6, 13, 30)); p.setTextSize(12); c.drawText("👑 ICON PLAYER", 356, photoBottom + 124, p);
        }

        // Dynamic settings-based data grid. Every selected setting gets rendered.
        ArrayList<String[]> fields = new ArrayList<>();
        if (showPlayerId) fields.add(new String[]{"Player ID", valueOrNA(pl.optString("pid", String.format(java.util.Locale.US, "%02d", pageNo)))});
        if (showPlace) fields.add(new String[]{"Place", valueOrNA(pl.optString("place"))});
        if (showRole) fields.add(new String[]{"Role", valueOrNA(role)});
        if (showBat) fields.add(new String[]{"Batting Style", valueOrNA(pl.optString("bat"))});
        if (showBowl) fields.add(new String[]{"Bowling Style", valueOrNA(pl.optString("bowl"))});
        if (showMobile) fields.add(new String[]{"Mobile", valueOrNA(pl.optString("mobile"))});
        if (showTeam) fields.add(new String[]{"Franchise", valueOrNA(pl.optString("team"))});
        if (showStatus) fields.add(new String[]{"Auction Status", cleanStatus(pl)});
        if (showBid) fields.add(new String[]{"Bid Points", pl.optInt("bid", 0) > 0 ? String.valueOf(pl.optInt("bid", 0)) : "Not sold"});
        if (showBase) fields.add(new String[]{"Base Points", String.valueOf(basePoints())});
        if (showIconFlag) fields.add(new String[]{"Icon Player", "ICON".equals(status) ? "Yes" : "No"});
        if (showIdPhoto) fields.add(new String[]{"ID Photo", pl.optString("idp", "").length() > 0 ? "Attached" : "Not uploaded"});

        int gridTop = Math.max(photoBottom + 156, 548);
        int chipH = fields.size() > 10 ? 38 : 43;
        int chipGap = 8;
        for (int i = 0; i < fields.size(); i++) {
            int col = i % 2;
            int row = i / 2;
            int x = col == 0 ? 62 : 304;
            int y = gridTop + row * (chipH + chipGap);
            if (y + chipH > 724) break;
            premiumPdfChip(c, p, fields.get(i)[0], fields.get(i)[1], x, y, 226, chipH, rolePrimary);
        }

        // ID photo mini proof area if enabled; never hides configured fields, appears as footer badge.
        if (showIdPhoto && pl.optString("idp", "").length() > 0) {
            p.setColor(Color.argb(190, 255, 248, 226)); c.drawRoundRect(new RectF(352, 688, 522, 736), 18, 18, p);
            p.setColor(Color.rgb(116, 24, 42)); p.setFakeBoldText(true); p.setTextSize(9); c.drawText("ID PHOTO PROOF", 370, 706, p);
            drawPlayerPhoto(c, pl.optString("idp"), 418, 710, 82, 20, p);
        }

        // Footer strip
        p.setShader(new android.graphics.LinearGradient(0, 786, 595, 786,
                new int[]{rolePrimary, Color.rgb(255, 216, 94), rolePrimary}, null, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(24, 786, 571, 818), 16, 16, p); p.setShader(null);
        p.setColor(Color.rgb(5, 10, 22)); p.setTextSize(10); p.setFakeBoldText(true);
        c.drawText("TEAM RDB • GOD-LEVEL CRICKET AUCTION CARD • RDB AUCTION MANAGER", 72, 806, p);
    }

    android.graphics.Path diagonalPath(float left, float top, float right, float bottom) {
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(left, top + 45); path.lineTo(right, top); path.lineTo(right, bottom - 70); path.lineTo(left, bottom); path.close();
        return path;
    }

    void drawGodLevelStadium(Canvas c, Paint p) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(95, 255, 216, 94)); c.drawCircle(92, 86, 20, p); c.drawCircle(502, 86, 20, p);
        p.setColor(Color.argb(45, 255, 255, 255));
        c.drawPath(lightBeam(92, 86, 252, 348, 340, 348), p); c.drawPath(lightBeam(502, 86, 255, 348, 345, 348), p);
        p.setColor(Color.rgb(8, 23, 49)); c.drawOval(-160, 92, 755, 360, p);
        p.setColor(Color.argb(55, 255, 255, 255)); c.drawOval(-112, 130, 707, 306, p);
        p.setColor(Color.rgb(8, 78, 57)); c.drawOval(-100, 690, 695, 910, p);
        p.setColor(Color.rgb(17, 129, 83)); c.drawOval(35, 737, 560, 858, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.argb(155, 255, 255, 255)); c.drawOval(132, 770, 463, 836, p);
        p.setStrokeWidth(3); p.setColor(Color.argb(130, 255, 216, 94)); c.drawLine(297, 738, 297, 842, p); c.drawOval(258, 769, 337, 834, p);
        p.setStyle(Paint.Style.FILL);
        // crowd sparkle dots
        p.setColor(Color.argb(100, 255, 216, 94));
        for (int i = 0; i < 24; i++) c.drawCircle(35 + (i * 23) % 545, 145 + (i * 17) % 95, 2 + (i % 3), p);
    }

    android.graphics.Path lightBeam(float sx, float sy, float x1, float y1, float x2, float y2) {
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(sx, sy); path.lineTo(x1, y1); path.lineTo(x2, y2); path.close();
        return path;
    }

    void drawTrophyGlyph(Canvas c, Paint p, int cx, int cy, int size) {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(170, 255, 216, 94));
        RectF cup = new RectF(cx - size/2, cy - size/2, cx + size/2, cy + size/3);
        c.drawRoundRect(cup, 14, 14, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.argb(150, 255, 236, 165));
        c.drawArc(new RectF(cx - size, cy - size/3, cx - size/3, cy + size/3), 270, -190, false, p);
        c.drawArc(new RectF(cx + size/3, cy - size/3, cx + size, cy + size/3), 270, 190, false, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(175, 255, 216, 94));
        c.drawRect(cx - 6, cy + size/3, cx + 6, cy + size/2, p); c.drawRoundRect(new RectF(cx - size/2, cy + size/2, cx + size/2, cy + size/2 + 12), 6, 6, p);
    }

    void drawCricketBatBall(Canvas c, Paint p, int x, int y) {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(145, 255, 216, 94));
        RectF bat = new RectF(x, y, x + 18, y + 88); c.save(); c.rotate(-28, x + 9, y + 44); c.drawRoundRect(bat, 7, 7, p); p.setColor(Color.argb(170, 255,255,255)); c.drawRect(x+5, y-18, x+13, y+12, p); c.restore();
        p.setColor(Color.rgb(196, 32, 51)); c.drawCircle(x + 54, y + 30, 14, p); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.WHITE); c.drawArc(new RectF(x+43, y+19, x+65, y+41), 90, 180, false, p); p.setStyle(Paint.Style.FILL);
    }

    void premiumPdfChip(Canvas c, Paint p, String k, String v, int x, int y, int w, int h, int accent) {
        RectF row = new RectF(x, y, x + w, y + h);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(120, 0, 0, 0)); c.drawRoundRect(new RectF(x+4, y+4, x+w+4, y+h+4), 16, 16, p);
        p.setShader(new android.graphics.LinearGradient(x, y, x + w, y,
                new int[]{Color.rgb(255, 248, 218), Color.rgb(236, 243, 255)}, null, android.graphics.Shader.TileMode.CLAMP));
        c.drawRoundRect(row, 16, 16, p); p.setShader(null);
        p.setColor(accent); c.drawRoundRect(new RectF(x, y, x + 9, y + h), 16, 16, p);
        p.setColor(Color.rgb(255, 216, 94)); c.drawRoundRect(new RectF(x + 15, y + 7, x + w - 10, y + 21), 8, 8, p);
        p.setFakeBoldText(true); p.setColor(Color.rgb(5, 10, 22)); p.setTextSize(7.5f); c.drawText(cut(k.toUpperCase(), 20), x + 26, y + 18, p);
        p.setFakeBoldText(true); p.setColor(Color.rgb(5, 10, 22)); p.setTextSize(h <= 38 ? 9.5f : 10.5f);
        c.drawText(cut(v, h <= 38 ? 27 : 30), x + 26, y + h - 10, p);
    }

    void pdfChip(Canvas c, Paint p, String k, String v, int x, int y, int w) {
        premiumPdfChip(c, p, k, v, x, y - 22, w, 46, Color.rgb(116, 24, 42));
    }

    int pdfDetail(Canvas c, Paint p, String k, String v, int y) {
        if (y > 728) return y;
        pdfChip(c, p, k, v, 62, y, 471);
        return y + 48;
    }

    int darker(int color) { return Color.rgb(Math.max(0, Color.red(color)-54), Math.max(0, Color.green(color)-54), Math.max(0, Color.blue(color)-54)); }
    int lighter(int color) { return Color.rgb(Math.min(255, Color.red(color)+58), Math.min(255, Color.green(color)+58), Math.min(255, Color.blue(color)+58)); }

    String valueOrNA(String v) {
        if (v == null || v.trim().length() == 0) return "Not specified";
        return v.trim();
    }

    int roleColor(String role) {
        if (role == null) return Color.rgb(93, 30, 42);
        if (role.indexOf("Bowler") >= 0) return Color.rgb(36, 88, 166);
        if (role.indexOf("Round") >= 0) return Color.rgb(93, 30, 42);
        if (role.indexOf("Keeper") >= 0) return Color.rgb(22, 120, 90);
        return Color.rgb(190, 126, 16);
    }

    String cleanStatus(JSONObject pl) {
        String st = pl.optString("status", "NEW");
        if ("ICON".equals(st)) return "Icon Player - " + pl.optString("team", "Assigned Team");
        if ("SOLD".equals(st)) return "Sold to " + pl.optString("team", "") + " for " + pl.optInt("bid", 0) + " points";
        if ("UNSOLD".equals(st)) return "Unsold";
        if ("RECALL".equals(st)) return "Recall Bucket";
        return "Available for Auction";
    }

    void writeFixturesPdf(Uri uri) {
        try {
            PdfDocument pdf = new PdfDocument(); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); int pageNo=1;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); Canvas c = page.getCanvas();
            int y = drawPdfHeader(c, p, "Fixtures");
            p.setTextSize(11);
            for(int i=0;i<fixtures.length();i++) {
                if (y > 790) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c = page.getCanvas(); y = drawPdfHeader(c,p,"Fixtures"); }
                JSONObject f=fixtures.getJSONObject(i);
                p.setStyle(Paint.Style.FILL); p.setColor(i%2==0 ? Color.rgb(245,247,251) : Color.rgb(232,238,246)); c.drawRoundRect(new RectF(28,y-18,567,y+36), 12,12,p);
                p.setColor(Color.rgb(93,30,42)); p.setFakeBoldText(true); p.setTextSize(10); c.drawText(String.valueOf(i+1), 40, y+2, p);
                p.setColor(Color.rgb(5,12,24)); p.setTextSize(12); c.drawText(f.optString("time") + "  •  " + f.optString("round"), 72, y+2, p);
                p.setFakeBoldText(false); p.setTextSize(13); c.drawText(cut(f.optString("teamA"),22) + "  vs  " + cut(f.optString("teamB"),22), 72, y+24, p);
                y += 60;
            }
            pdf.finishPage(page); OutputStream os=getContentResolver().openOutputStream(uri); pdf.writeTo(os); os.close(); pdf.close(); toast("Fixtures PDF exported");
        } catch(Exception e) { toast("Fixtures PDF failed: " + e.toString()); }
    }

    int drawPdfHeader(Canvas c, Paint p, String scope) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(2, 6, 18)); c.drawRect(0,0,595,126,p);
        p.setColor(Color.rgb(7, 19, 48)); c.drawRect(0,0,595,72,p);
        p.setColor(Color.rgb(116,24,42)); c.drawRect(0,72,595,120,p);
        p.setColor(Color.rgb(244,184,62)); c.drawRect(0,120,595,126,p);
        p.setTextSize(23); p.setFakeBoldText(true); p.setColor(Color.rgb(244,184,62));
        String title = "Fixtures".equals(scope) ? "MATCH FIXTURES" : "TEAM REVEAL POSTER";
        c.drawText("RDB AUCTION MANAGER", 28, 34, p);
        p.setColor(Color.WHITE); p.setTextSize(15); c.drawText(cut(sp.getString("auctionName", "Tournament") + " • " + title, 48), 28, 63, p);
        p.setFakeBoldText(false); p.setTextSize(10); p.setColor(Color.rgb(218,226,238));
        c.drawText("Scope: " + scope + " | Teams: " + teams.length() + " | Players: " + players.length() + " | © Team RDB", 28, 94, p);
        return 148;
    }

    int drawTeamPdfBlock(Canvas c, Paint p, String tn, int y) throws Exception {
        JSONObject tm = findTeam(tn);
        int top = y - 8;
        RectF poster = new RectF(26, top, 569, 790);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(4, 10, 22)); c.drawRoundRect(poster, 26, 26, p);
        p.setColor(Color.rgb(7, 22, 50)); c.drawOval(-40, top + 10, 640, top + 230, p);
        p.setColor(Color.argb(90, 22, 148, 104)); c.drawOval(30, 720, 565, 840, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.rgb(244,184,62)); c.drawRoundRect(poster, 26, 26, p);
        p.setStyle(Paint.Style.FILL);

        p.setColor(Color.rgb(116,24,42)); c.drawRoundRect(new RectF(44, top + 20, 551, top + 88), 22, 22, p);
        p.setColor(Color.rgb(244,184,62)); p.setFakeBoldText(true); p.setTextSize(13); c.drawText("OFFICIAL TEAM REVEAL", 64, top + 49, p);
        p.setColor(Color.WHITE); p.setTextSize(tn.length() > 20 ? 25 : 31); c.drawText(cut(tn.toUpperCase(), 27), 64, top + 78, p);

        if (tm != null) drawPlayerPhoto(c, tm.optString("logo"), 424, top + 29, 90, 50, p);
        else { p.setColor(Color.rgb(235,241,248)); c.drawRoundRect(new RectF(424, top + 29, 514, top + 79), 12, 12, p); }

        int spent = teamSpent(tn), bal = teamBalance(tn), count = teamCount(tn);
        pdfStat(c, p, "SQUAD", count + "/" + totalSlots(), 58, top + 122);
        pdfStat(c, p, "SPENT", String.valueOf(spent), 205, top + 122);
        pdfStat(c, p, "BALANCE", String.valueOf(bal), 352, top + 122);

        JSONObject icon = null;
        ArrayList<JSONObject> squad = new ArrayList<>();
        for (int i=0;i<players.length();i++) {
            JSONObject pl=players.getJSONObject(i);
            if(tn.equals(pl.optString("team"))) {
                if("ICON".equals(pl.optString("status"))) icon=pl;
                else squad.add(pl);
            }
        }

        int rowY = top + 220;
        if (icon != null) {
            p.setColor(Color.rgb(255,248,224)); c.drawRoundRect(new RectF(52,rowY-16,543,rowY+88), 22, 22, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(244,184,62)); c.drawRoundRect(new RectF(52,rowY-16,543,rowY+88), 22, 22, p); p.setStyle(Paint.Style.FILL);
            drawPlayerPhoto(c, icon.optString("photo"), 66, rowY, 78, 72, p);
            p.setColor(Color.rgb(116,24,42)); p.setFakeBoldText(true); p.setTextSize(13); c.drawText("👑 ICON PLAYER", 164, rowY + 18, p);
            p.setColor(Color.rgb(4,10,22)); p.setTextSize(19); c.drawText(cut(icon.optString("name").toUpperCase(), 28), 164, rowY + 45, p);
            p.setFakeBoldText(false); p.setTextSize(11); c.drawText("ID " + icon.optString("pid", "--") + " • " + cut(cleanRole(icon.optString("role")), 28), 164, rowY + 67, p);
            rowY += 126;
        }

        p.setColor(Color.rgb(244,184,62)); p.setFakeBoldText(true); p.setTextSize(14); c.drawText("SQUAD LINE-UP", 58, rowY, p);
        rowY += 22;
        int col = 0;
        for (int i=0;i<squad.size();i++) {
            JSONObject pl = squad.get(i);
            int x = col == 0 ? 58 : 309;
            drawMiniPlayerCard(c, p, pl, x, rowY);
            if (col == 1) { col = 0; rowY += 76; } else col = 1;
            if (rowY > 728) break;
        }
        if (squad.size() == 0 && icon == null) {
            p.setColor(Color.rgb(235,241,248)); c.drawRoundRect(new RectF(58,rowY,537,rowY+70), 18, 18, p);
            p.setColor(Color.rgb(4,10,22)); p.setTextSize(15); p.setFakeBoldText(true); c.drawText("No players assigned yet", 190, rowY+42, p);
        }

        p.setColor(Color.rgb(244,184,62)); c.drawRect(26, 796, 569, 801, p);
        p.setColor(Color.rgb(190,202,216)); p.setTextSize(10); p.setFakeBoldText(false); c.drawText("Generated by RDB Auction Manager • Professional cricket team reveal poster", 48, 822, p);
        return 820;
    }

    void pdfStat(Canvas c, Paint p, String label, String value, int x, int y) {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(235,241,248)); c.drawRoundRect(new RectF(x,y,x+126,y+62), 18,18,p);
        p.setColor(Color.rgb(244,184,62)); c.drawRoundRect(new RectF(x,y,x+126,y+22), 18,18,p);
        p.setColor(Color.rgb(4,10,22)); p.setFakeBoldText(true); p.setTextSize(9); c.drawText(label, x+16, y+15, p);
        p.setTextSize(18); c.drawText(cut(value,10), x+16, y+48, p);
    }

    void drawMiniPlayerCard(Canvas c, Paint p, JSONObject pl, int x, int y) {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(235,241,248)); c.drawRoundRect(new RectF(x,y,x+228,y+62), 16,16,p);
        p.setColor(roleColor(cleanRole(pl.optString("role")))); c.drawRoundRect(new RectF(x,y,x+228,y+18), 16,16,p);
        drawPlayerPhoto(c, pl.optString("photo"), x+8, y+22, 36, 32, p);
        p.setColor(Color.rgb(4,10,22)); p.setFakeBoldText(true); p.setTextSize(11); c.drawText(cut(pl.optString("pid", "--") + " • " + pl.optString("name"), 25), x+52, y+36, p);
        p.setFakeBoldText(false); p.setTextSize(9); c.drawText(cut(cleanRole(pl.optString("role")) + " • " + pl.optInt("bid",0) + " pts", 30), x+52, y+52, p);
    }

    JSONObject findTeam(String tn) {
        try { for (int i=0;i<teams.length();i++) { JSONObject t = teams.getJSONObject(i); if (tn.equals(t.optString("name"))) return t; } } catch(Exception e) { }
        return null;
    }

    void drawPlayerPhoto(Canvas c, String uri, int x, int y, int w, int h, Paint p) {
        RectF frame = new RectF(x, y, x + w, y + h);
        try {
            if (uri != null && uri.length() > 0) {
                Bitmap b = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(uri)));
                if (b != null) {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Color.rgb(6, 13, 26));
                    c.drawRoundRect(frame, 8, 8, p);

                    float bw = b.getWidth();
                    float bh = b.getHeight();
                    float scale = Math.min(w / bw, h / bh); // aspect-fit: never stretch
                    float dw = bw * scale;
                    float dh = bh * scale;
                    float left = x + (w - dw) / 2f;
                    float top = y + (h - dh) / 2f;
                    RectF dest = new RectF(left, top, left + dw, top + dh);
                    c.drawBitmap(b, null, dest, p);
                    return;
                }
            }
        } catch (Exception e) { }
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(220,225,232)); c.drawRoundRect(frame, 8, 8, p);
        p.setColor(Color.rgb(90,100,112)); p.setTextSize(10); c.drawText("PHOTO", x+8, y+h/2+4, p);
    }

    String cut(String s, int n) { return s == null ? "" : (s.length() <= n ? s : s.substring(0,n-1)); }

    public void onBackPressed() { home(); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    public class StadiumBackdrop extends View {
        Paint p = new Paint(1);
        public StadiumBackdrop(android.content.Context c) { super(c); }
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 255, 255, 255));
            for (int i = 0; i < 6; i++) {
                float x = (w / 7f) * (i + 1);
                p.setColor(Color.argb(70, 255, 230, 150));
                c.drawCircle(x, h * 0.16f, 24, p);
                p.setStrokeWidth(3);
                p.setColor(Color.argb(38, 244, 184, 62));
                c.drawLine(x, h * 0.16f, w/2f, h*0.52f, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 177, 36, 47));
            c.drawOval(-w*0.15f, h*0.72f, w*1.15f, h*1.10f, p);
            p.setColor(Color.argb(110, 12, 95, 62));
            c.drawOval(-w*0.05f, h*0.77f, w*1.05f, h*1.03f, p);
            p.setColor(Color.argb(120, 244, 184, 62));
            p.setStrokeWidth(5);
            p.setStyle(Paint.Style.STROKE);
            c.drawOval(w*0.10f, h*0.80f, w*0.90f, h*0.98f, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(54);
            p.setColor(Color.argb(28, 255, 255, 255));
            c.drawText("CRICKET AUCTION", w*0.08f, h*0.92f, p);
        }
    }

}
