package com.josco.jsauctions;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation;
import android.os.Environment;
import java.io.OutputStream;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    // RDB cricket theme: deep navy + maroon + stadium gold.
    int bg = Color.rgb(4, 10, 22);
    int panel = Color.rgb(12, 24, 42);
    int panel2 = Color.rgb(18, 38, 62);
    int gold = Color.rgb(244, 184, 62);
    int blue = Color.rgb(36, 159, 184);
    int green = Color.rgb(22, 148, 104);
    int red = Color.rgb(177, 36, 47);
    int orange = Color.rgb(218, 112, 42);
    int text = Color.rgb(246, 248, 252);
    int muted = Color.rgb(190, 202, 216);

    LinearLayout root;
    SharedPreferences sp;
    JSONArray players = new JSONArray();
    JSONArray teams = new JSONArray();
    JSONArray deck = new JSONArray();
    int currentIndex = -1;
    String pickTarget = "";
    int editingTeamIndex = -1;
    int roundNo = 0;
    boolean auctionEnded = false;

    String[] roles = {"🏏 Batsman", "⚡ Bowler", "⭐ All Rounder", "🧤 Wicket Keeper Batsman"};
    String[] bats = {"Right hand bat", "Left hand bat"};
    String[] bowls = {"Right arm fast", "Right arm medium", "Right arm off spin", "Right arm leg spin", "Left arm fast", "Left arm medium", "Left arm orthodox", "Left arm wrist spin", "None"};

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("db", 0);
        setDefaults();
        load();
        intro();
    }

    void setDefaults() {
        if (!sp.contains("playersPerTeam")) {
            sp.edit()
                    .putInt("playersPerTeam", 11)
                    .putBoolean("bench", false)
                    .putInt("benchCount", 2)
                    .putInt("maxBucket", 11000)
                    .putInt("basePoints", 300)
                    .putString("increments", "300-999:50\n1000-2999:100\n3000-99999:250")
                    .putString("auctionName", "KPL Season 1")
                    .putBoolean("auctionEnded", false)
                    .putInt("roundNo", 0)
                    .apply();
        }
    }

    void load() {
        try {
            players = new JSONArray(sp.getString("players", "[]"));
            teams = new JSONArray(sp.getString("teams", "[]"));
            deck = new JSONArray(sp.getString("deck", "[]"));
            currentIndex = sp.getInt("idx", -1);
            roundNo = sp.getInt("roundNo", 0);
            auctionEnded = sp.getBoolean("auctionEnded", false);
        } catch (Exception e) { }
    }

    void save() {
        sp.edit().putString("players", players.toString()).putString("teams", teams.toString()).putString("deck", deck.toString()).putInt("idx", currentIndex).putInt("roundNo", roundNo).putBoolean("auctionEnded", auctionEnded).apply();
    }

    GradientDrawable bgShape(int color, int strokeColor, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (stroke > 0) g.setStroke(stroke, strokeColor);
        return g;
    }

    String roleIcon(String role) {
        if (role == null) return "🏏";
        if (role.indexOf("Bowler") >= 0) return "⚡";
        if (role.indexOf("Round") >= 0) return "⭐";
        if (role.indexOf("Keeper") >= 0) return "🧤";
        return "🏏";
    }

    void footer() {
        TextView f = tv("Owned by Team RDB • Creator: Josco\n© 2026 Team RDB. All rights reserved. This application, auction workflow, UI concepts, data structure and tournament management system are proprietary work of Team RDB. Unauthorized reproduction, redistribution, reverse engineering or commercial reuse is prohibited.", 12, Color.LTGRAY);
        f.setGravity(Gravity.CENTER);
        f.setPadding(12, 28, 12, 12);
        root.addView(f);
    }

    int totalSlots() { return sp.getInt("playersPerTeam", 11) + (sp.getBoolean("bench", false) ? sp.getInt("benchCount", 2) : 0); }
    int maxBucket() { return sp.getInt("maxBucket", 11000); }
    int basePoints() { return sp.getInt("basePoints", 300); }

    TextView tv(String s, int size, int c) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(c);
        v.setPadding(18, 10, 18, 10);
        return v;
    }

    TextView label(String s) {
        TextView v = tv(s, 14, muted);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    TextView title(String s) {
        TextView v = tv(s, 24, gold);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    GradientDrawable buttonShape(int color) {
        int end = darken(color, 42);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{color, end});
        g.setCornerRadius(30);
        g.setStroke(2, Color.argb(190, 244, 184, 62));
        return g;
    }

    int darken(int c, int amount) {
        return Color.rgb(Math.max(0, Color.red(c)-amount), Math.max(0, Color.green(c)-amount), Math.max(0, Color.blue(c)-amount));
    }

    Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(text);
        b.setShadowLayer(3, 0, 1, Color.BLACK);
        b.setBackground(buttonShape(color));
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(20, 16, 20, 16);
        return b;
    }

    void addBtn(String s, int color, View.OnClickListener l) {
        Button b = btn(s, color);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        root.addView(b, lp);
    }

    LinearLayout cardBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16, 16, 16, 16);
        box.setBackground(bgShape(panel, Color.rgb(67, 85, 130), 26, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 10, 0, 12);
        root.addView(box, lp);
        return box;
    }


    void intro() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(28, 28, 28, 28);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(2, 5, 14), Color.rgb(24, 6, 18), Color.rgb(4, 17, 30)});
        wrap.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(gd);
        frame.addView(new StadiumBackdrop(this), new FrameLayout.LayoutParams(-1, -1));
        frame.addView(wrap, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("rdblogo", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(320, 320);
        ilp.setMargins(0, 0, 0, 20);
        wrap.addView(logo, ilp);

        TextView app = title("J's Auction Manager");
        app.setTextSize(32);
        app.setTextColor(gold);
        app.setShadowLayer(10, 0, 0, Color.rgb(160, 35, 45));
        wrap.addView(app);

        TextView tag = tv("Premium Cricket Auction Manager", 18, text);
        tag.setGravity(Gravity.CENTER);
        tag.setTypeface(Typeface.DEFAULT_BOLD);
        wrap.addView(tag);

        TextView own = tv("Owned By Team RDB", 16, gold);
        own.setGravity(Gravity.CENTER);
        wrap.addView(own);

        TextView cr = tv("Created By Josco", 15, muted);
        cr.setGravity(Gravity.CENTER);
        wrap.addView(cr);

        animateIn(logo, 0);
        animateIn(app, 350);
        animateIn(tag, 700);
        animateIn(own, 1050);
        animateIn(cr, 1350);

        new Handler().postDelayed(new Runnable() { public void run() { home(); } }, 3300);
    }

    void animateIn(View v, long delay) {
        v.setAlpha(0f);
        v.setTranslationY(50f);
        v.animate().alpha(1f).translationY(0f).setDuration(850).setStartDelay(delay).start();
    }

    void base(String screenTitle) {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 24, 18, 24);
        root.setBackgroundColor(bg);
        sv.addView(root);
        setContentView(sv);
        TextView h = title("J's Auction Manager");
        root.addView(h);
        if (screenTitle != null && screenTitle.trim().length() > 0) {
            TextView sub = tv(screenTitle, 14, muted);
            sub.setGravity(Gravity.CENTER);
            root.addView(sub);
        }
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(text);
        e.setHintTextColor(muted);
        e.setSingleLine(false);
        e.setBackground(bgShape(panel2, Color.rgb(80, 100, 150), 18, 1));
        e.setPadding(16, 10, 16, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(e, lp);
        return e;
    }

    Spinner spin(String[] arr) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr) { public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; } public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }};
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    void home() {
        base("");
        LinearLayout hero = cardBox();
        hero.setBackground(bgShape(Color.rgb(13, 24, 43), gold, 34, 2));
        hero.addView(tv("🏟️  " + sp.getString("auctionName", "KPL Season 1"), 24, gold));
        hero.addView(tv("Teams Registered: " + teams.length(), 16, text));
        hero.addView(tv("Players Registered: " + players.length(), 16, text));
        hero.addView(tv("Current Round: " + roundNo, 15, muted));
        addBtn("➕ Add Player", blue, v -> playerForm());
        addBtn("🛡️ Add Franchisee / Team", red, v -> teamForm());
        addBtn("🎙️ Start / Continue Auction", green, v -> auction());
        addBtn("📋 Teams, Logos & Squads", blue, v -> teamsView());
        addBtn("🔁 Unsold / Recall Buckets", orange, v -> buckets());
        addBtn("⚙️ Auction Settings", red, v -> settings());
        addBtn("📄 Export Team List PDF", green, v -> exportPdf());
        footer();
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, 5);
    }

    public void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 5 && c == RESULT_OK && d != null) {
            Uri u = d.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
            SharedPreferences.Editor ed = sp.edit();
            if ("photo".equals(pickTarget)) ed.putString("last_photo", u.toString());
            else if ("id".equals(pickTarget)) ed.putString("last_id", u.toString());
            else if ("teamLogo".equals(pickTarget)) ed.putString("last_team_logo", u.toString());
            ed.apply();
            toast("Image selected. Now press Save.");
        }
        if (r == 7 && c == RESULT_OK && d != null) {
            writePdf(d.getData());
        }
    }

    void playerForm() {
        base("Add Player");
        root.addView(label("Player name"));
        EditText name = input("Example: Sanju Samson");
        root.addView(label("Player role"));
        Spinner role = spin(roles);
        root.addView(label("Batting style"));
        Spinner bat = spin(bats);
        root.addView(label("Bowling style"));
        Spinner bowl = spin(bowls);
        addBtn("Upload Player Photo", blue, v -> { pickTarget = "photo"; pickImage(); });
        addBtn("Upload Aadhaar / ID Photo", orange, v -> { pickTarget = "id"; pickImage(); });
        addBtn("Save Player", green, v -> {
            try {
                if (name.getText().toString().trim().length() == 0) { toast("Enter player name"); return; }
                JSONObject o = new JSONObject();
                o.put("name", name.getText().toString().trim());
                o.put("role", role.getSelectedItem().toString());
                o.put("bat", bat.getSelectedItem().toString());
                o.put("bowl", bowl.getSelectedItem().toString());
                o.put("photo", sp.getString("last_photo", ""));
                o.put("idp", sp.getString("last_id", ""));
                o.put("status", "NEW");
                o.put("team", "");
                o.put("bid", 0);
                players.put(o);
                sp.edit().remove("last_photo").remove("last_id").apply();
                save();
                toast("Player saved");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    void teamForm() {
        base("Add Franchisee / Team");
        root.addView(label("Team / franchisee name"));
        EditText n = input("Example: RDB");
        addBtn("Upload Team Logo", blue, v -> { pickTarget = "teamLogo"; pickImage(); });
        addBtn("Save Team", green, v -> {
            try {
                if (n.getText().toString().trim().length() == 0) { toast("Enter team name"); return; }
                JSONObject o = new JSONObject();
                o.put("name", n.getText().toString().trim());
                o.put("logo", sp.getString("last_team_logo", ""));
                teams.put(o);
                sp.edit().remove("last_team_logo").apply();
                save();
                toast("Team saved");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    int teamCount(String t) throws Exception {
        int c = 0;
        for (int i = 0; i < players.length(); i++) if (t.equals(players.getJSONObject(i).optString("team"))) c++;
        return c;
    }

    int teamSpent(String t) throws Exception {
        int spent = 0;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.getJSONObject(i);
            if (t.equals(p.optString("team"))) spent += p.optInt("bid", 0);
        }
        return spent;
    }

    int teamBalance(String t) throws Exception { return maxBucket() - teamSpent(t); }

    int maxBidForTeam(String t) throws Exception {
        int bought = teamCount(t);
        int slots = totalSlots();
        if (bought >= slots) return 0;
        int balance = teamBalance(t);
        int reserveAfterCurrentBuy = (slots - bought - 1) * basePoints();
        int maxBid = balance - reserveAfterCurrentBuy;
        return Math.max(0, maxBid);
    }

    int nextIncrementFor(int bid) {
        String cfg = sp.getString("increments", "300-999:50\n1000-2999:100\n3000-99999:250");
        String[] lines = cfg.split("\\n");
        for (String line : lines) {
            try {
                line = line.trim();
                if (line.length() == 0 || !line.contains(":")) continue;
                String[] lrInc = line.split(":");
                String[] lr = lrInc[0].split("-");
                int low = Integer.parseInt(lr[0].trim());
                int high = Integer.parseInt(lr[1].trim());
                int inc = Integer.parseInt(lrInc[1].trim());
                if (bid >= low && bid <= high) return inc;
            } catch (Exception e) { }
        }
        return 100;
    }

    void showTeamPoints() {
        try {
            LinearLayout box = cardBox();
            box.addView(tv("Live Bucket Table", 20, gold));
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            TableLayout table = new TableLayout(this);
            table.setStretchAllColumns(true);
            table.addView(row(new String[]{"TEAM", "SQUAD", "SPENT", "BALANCE", "MAX BID", "NEXT INC"}, true));
            for (int i = 0; i < teams.length(); i++) {
                String tn = teams.getJSONObject(i).optString("name");
                int mb = maxBidForTeam(tn);
                table.addView(row(new String[]{tn, teamCount(tn)+"/"+totalSlots(), String.valueOf(teamSpent(tn)), String.valueOf(teamBalance(tn)), String.valueOf(mb), String.valueOf(nextIncrementFor(Math.max(basePoints(), mb)))}, false));
            }
            hsv.addView(table);
            box.addView(hsv);
        } catch (Exception e) { }
    }

    TableRow row(String[] vals, boolean header) {
        TableRow tr = new TableRow(this);
        tr.setBackgroundColor(header ? Color.rgb(76, 55, 10) : panel2);
        for (String v : vals) {
            TextView cell = tv(v, header ? 13 : 14, header ? gold : text);
            cell.setTypeface(Typeface.DEFAULT_BOLD);
            cell.setPadding(18, 14, 18, 14);
            tr.addView(cell);
        }
        return tr;
    }

    void newRound() {
        try {
            ArrayList<Integer> ids = new ArrayList<Integer>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                String st = p.optString("status", "NEW");
                if ("SOLD".equals(st)) continue;
                if (roundNo == 0 && "NEW".equals(st)) ids.add(i);
                else if (roundNo > 0 && ("UNSOLD".equals(st) || "RECALL".equals(st))) ids.add(i);
            }
            if (ids.size() == 0 && roundNo == 0) {
                for (int i = 0; i < players.length(); i++) if (!"SOLD".equals(players.getJSONObject(i).optString("status"))) ids.add(i);
            }
            Collections.shuffle(ids);
            deck = new JSONArray();
            for (int x : ids) deck.put(x);
            currentIndex = ids.size() == 0 ? -1 : 0;
            if (ids.size() > 0) roundNo++;
            auctionEnded = false;
            save();
        } catch (Exception e) { }
    }

    ArrayList<String> availableTeams() throws Exception {
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < teams.length(); i++) {
            String tn = teams.getJSONObject(i).optString("name");
            if (teamCount(tn) < totalSlots()) names.add(tn);
        }
        return names;
    }

    void auction() {
        base("Auction Room");
        showTeamPoints();
        if (auctionEnded) {
            root.addView(tv("Auction ended manually. You can export PDF or reset auction status from Settings.", 18, gold));
            addBtn("Export Team List PDF", green, v -> exportPdf());
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (players.length() == 0 || teams.length() == 0) {
            root.addView(tv("Add players and franchisees first.", 18, text));
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (allSoldOrFull()) {
            root.addView(tv("Auction completed or all teams are full.", 20, green));
            addBtn("Teams & Players", blue, v -> teamsView());
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (deck.length() == 0 || currentIndex < 0 || currentIndex >= deck.length()) {
            LinearLayout info = cardBox();
            info.addView(tv(roundNo == 0 ? "Start First Round" : "Start Next Unsold/Recall Round", 22, gold));
            info.addView(tv("Round rules: First round displays every NEW player once in random order. Next rounds use only UNSOLD + RECALL players, randomly once each. SOLD players never return.", 15, text));
            addBtn(roundNo == 0 ? "Start First Random Round" : "Start Next Round", green, v -> { newRound(); auction(); });
            addBtn("End Auction", red, v -> { auctionEnded = true; save(); home(); });
            addBtn("Back", panel2, v -> home());
            return;
        }
        try {
            int pi = deck.getInt(currentIndex);
            JSONObject p = players.getJSONObject(pi);
            LinearLayout box = cardBox();
            box.addView(tv("Auction Card " + (currentIndex + 1) + " / " + deck.length(), 15, gold));
            ImageView iv = new ImageView(this);
            String ph = p.optString("photo", "");
            if (ph.length() > 0) iv.setImageURI(Uri.parse(ph));
            else iv.setBackgroundColor(panel2);
            iv.setAdjustViewBounds(true);
            iv.setMaxHeight(560);
            box.addView(iv, new LinearLayout.LayoutParams(-1, -2));
            box.addView(tv(roleIcon(p.optString("role")) + "  " + p.optString("name"), 29, text));
            box.addView(tv("Role: " + p.optString("role") + "\n🏏 Batting: " + p.optString("bat") + "\n⚡ Bowling: " + p.optString("bowl") + "\nBase Points: " + basePoints(), 16, Color.LTGRAY));

            root.addView(label("Sold to team"));
            ArrayList<String> ok = availableTeams();
            Spinner ts = new Spinner(this);
            ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ok) { public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; } public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }};
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            ts.setAdapter(ad);
            root.addView(ts);

            root.addView(label("Sold bid value / bucket points"));
            EditText bid = input("Enter final bid points");
            bid.setInputType(InputType.TYPE_CLASS_NUMBER);
            bid.setText(String.valueOf(basePoints()));

            TextView hint = tv("Select a team to view max bid.", 14, Color.LTGRAY);
            root.addView(hint);
            ts.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                public void onItemSelected(android.widget.AdapterView<?> parent, View view, int pos, long id) {
                    try {
                        String tn = parent.getItemAtPosition(pos).toString();
                        int mb = maxBidForTeam(tn);
                        hint.setText(tn + " can bid up to " + mb + ". Increment at current bid: " + nextIncrementFor(toInt(bid.getText().toString(), basePoints())));
                    } catch (Exception e) { }
                }
                public void onNothingSelected(android.widget.AdapterView<?> parent) { }
            });

            addBtn("SOLD - Add to Selected Team", green, v -> {
                try {
                    if (ts.getCount() == 0) { toast("All teams are full"); return; }
                    String tn = ts.getSelectedItem().toString();
                    int val = toInt(bid.getText().toString(), 0);
                    if (val < basePoints()) { toast("Bid cannot be below base points"); return; }
                    int max = maxBidForTeam(tn);
                    if (val > max) { toast("Bid exceeds max allowed for " + tn + ": " + max); return; }
                    JSONObject pp = players.getJSONObject(pi);
                    pp.put("status", "SOLD");
                    pp.put("team", tn);
                    pp.put("bid", val);
                    next();
                } catch (Exception e) { toast(e.toString()); }
            });
            addBtn("UNSOLD - Move to Unsold Bucket", red, v -> mark(pi, "UNSOLD"));
            addBtn("RECALL - Move to Recall Bucket", orange, v -> mark(pi, "RECALL"));
            addBtn("End Auction", red, v -> { auctionEnded = true; save(); home(); });
            addBtn("Back", panel2, v -> home());
        } catch (Exception e) {
            root.addView(tv(e.toString(), 14, red));
        }
    }

    int toInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    boolean allSoldOrFull() {
        try {
            boolean anyUnsold = false;
            for (int i = 0; i < players.length(); i++) if (!"SOLD".equals(players.getJSONObject(i).optString("status"))) anyUnsold = true;
            if (!anyUnsold) return true;
            boolean anyTeamSlot = false;
            for (int i = 0; i < teams.length(); i++) if (teamCount(teams.getJSONObject(i).optString("name")) < totalSlots()) anyTeamSlot = true;
            return !anyTeamSlot;
        } catch (Exception e) { return false; }
    }

    void mark(int i, String s) {
        try {
            players.getJSONObject(i).put("status", s);
            players.getJSONObject(i).put("team", "");
            players.getJSONObject(i).put("bid", 0);
            next();
        } catch (Exception e) { }
    }

    void next() {
        currentIndex++;
        save();
        if (currentIndex >= deck.length()) {
            deck = new JSONArray();
            currentIndex = -1;
            save();
            toast("Round completed");
        }
        auction();
    }

    void teamsView() {
        base("Teams & Squads");
        try {
            root.addView(tv("Squad slots: " + totalSlots() + " | Max bucket: " + maxBucket() + " | Base: " + basePoints(), 15, gold));
            for (int t = 0; t < teams.length(); t++) {
                JSONObject team = teams.getJSONObject(t);
                String tn = team.optString("name");
                LinearLayout box = cardBox();
                String logo = team.optString("logo", "");
                if (logo.length() > 0) {
                    ImageView iv = new ImageView(this);
                    iv.setImageURI(Uri.parse(logo));
                    iv.setAdjustViewBounds(true);
                    iv.setMaxHeight(220);
                    box.addView(iv);
                }
                box.addView(tv(tn + "  (" + teamCount(tn) + "/" + totalSlots() + ")", 22, gold));
                box.addView(tv("Spent: " + teamSpent(tn) + " | Balance: " + teamBalance(tn) + " | Max Bid: " + maxBidForTeam(tn), 14, text));
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (tn.equals(p.optString("team"))) box.addView(tv("• " + p.optString("name") + " - " + p.optString("role") + " - " + p.optInt("bid") + " pts", 15, Color.LTGRAY));
                }
                final int delIndex = t;
                Button db = btn("Delete " + tn, red);
                db.setOnClickListener(v -> confirmDeleteTeam(delIndex));
                box.addView(db);
            }
        } catch (Exception e) { root.addView(tv(e.toString(), 14, red)); }
        addBtn("Export Team List PDF", green, v -> exportPdf());
        addBtn("Back", panel2, v -> home());
    }

    void confirmDeleteTeam(int idx) {
        try {
            String tn = teams.getJSONObject(idx).optString("name");
            new AlertDialog.Builder(this).setTitle("Delete team?").setMessage("Delete " + tn + "? Sold players in this team will be moved to RECALL bucket and their bid will be cleared.")
                    .setPositiveButton("Delete", (d,w) -> deleteTeam(idx))
                    .setNegativeButton("Cancel", null).show();
        } catch (Exception e) { toast(e.toString()); }
    }

    void deleteTeam(int idx) {
        try {
            String tn = teams.getJSONObject(idx).optString("name");
            JSONArray nt = new JSONArray();
            for (int i = 0; i < teams.length(); i++) if (i != idx) nt.put(teams.getJSONObject(i));
            teams = nt;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if (tn.equals(p.optString("team"))) { p.put("team", ""); p.put("bid", 0); p.put("status", "RECALL"); }
            }
            deck = new JSONArray(); currentIndex = -1; save(); toast("Team deleted"); teamsView();
        } catch (Exception e) { toast(e.toString()); }
    }

    void buckets() {
        base("Unsold / Recall Buckets");
        try {
            LinearLayout u = cardBox();
            u.addView(tv("UNSOLD", 22, red));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if ("UNSOLD".equals(p.optString("status"))) u.addView(tv("• " + p.optString("name") + " | " + p.optString("role") + " | Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 15, text));
            }
            LinearLayout r = cardBox();
            r.addView(tv("RECALL", 22, orange));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if ("RECALL".equals(p.optString("status"))) r.addView(tv("• " + p.optString("name") + " | " + p.optString("role") + " | Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 15, text));
            }
        } catch (Exception e) { }
        addBtn("Back", panel2, v -> home());
    }

    void settings() {
        base("Auction Settings");
        root.addView(label("Auction / Tournament name"));
        EditText an = input("Example: KPL Season 1");
        an.setText(sp.getString("auctionName", "KPL Season 1"));
        root.addView(label("Main squad players per team"));
        EditText ppt = input("11");
        ppt.setInputType(InputType.TYPE_CLASS_NUMBER);
        ppt.setText(String.valueOf(sp.getInt("playersPerTeam", 11)));

        CheckBox cb = new CheckBox(this);
        cb.setText("Enable bench players");
        cb.setTextColor(text);
        cb.setChecked(sp.getBoolean("bench", false));
        root.addView(cb);

        root.addView(label("Bench count per team"));
        EditText bc = input("2");
        bc.setInputType(InputType.TYPE_CLASS_NUMBER);
        bc.setText(String.valueOf(sp.getInt("benchCount", 2)));

        root.addView(label("Maximum bucket points per team"));
        EditText max = input("11000");
        max.setInputType(InputType.TYPE_CLASS_NUMBER);
        max.setText(String.valueOf(maxBucket()));

        root.addView(label("Base points per player"));
        EditText base = input("300");
        base.setInputType(InputType.TYPE_CLASS_NUMBER);
        base.setText(String.valueOf(basePoints()));

        root.addView(label("Bid increment ranges: start-end:increment"));
        EditText inc = input("300-999:50\n1000-2999:100\n3000-99999:250");
        inc.setSingleLine(false);
        inc.setMinLines(3);
        inc.setText(sp.getString("increments", "300-999:50\n1000-2999:100\n3000-99999:250"));

        LinearLayout info = cardBox();
        info.addView(tv("🏆 Professional Auction Rules", 18, gold));
        info.addView(tv("Maximum bid = current balance - ((total slots - players already bought - 1) x base points). Example: 11000 - ((11 - 0 - 1) x 300) = 8000. Edge cases handled: full squads, bid below base, over-budget bid, deleted teams, reset rounds, sold players never returning, unsold/recall-only later rounds.", 14, text));

        addBtn("Save Settings", green, v -> {
            sp.edit()
                    .putInt("playersPerTeam", Math.max(1, toInt(ppt.getText().toString(), 11)))
                    .putBoolean("bench", cb.isChecked())
                    .putInt("benchCount", Math.max(0, toInt(bc.getText().toString(), 2)))
                    .putInt("maxBucket", Math.max(0, toInt(max.getText().toString(), 11000)))
                    .putInt("basePoints", Math.max(0, toInt(base.getText().toString(), 300)))
                    .putString("increments", inc.getText().toString())
                    .putString("auctionName", an.getText().toString().trim().length()==0 ? "J's Auction Manager" : an.getText().toString().trim())
                    .apply();
            toast("Settings saved");
            home();
        });
        addBtn("Reset Auction Status Only", red, v -> {
            try {
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    p.put("status", "NEW");
                    p.put("team", "");
                    p.put("bid", 0);
                }
                deck = new JSONArray();
                currentIndex = -1;
                roundNo = 0;
                auctionEnded = false;
                save();
                toast("Auction reset");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Clear ALL Data - Players, Teams, Auction", red, v -> confirmClearAll());
        addBtn("Back", panel2, v -> home());
    }

    void confirmClearAll() {
        new AlertDialog.Builder(this).setTitle("Clear all data?").setMessage("This deletes all players, teams, photos links, auction rounds, bids, and buckets from this app.")
                .setPositiveButton("Clear All", (d,w) -> { players = new JSONArray(); teams = new JSONArray(); deck = new JSONArray(); currentIndex=-1; roundNo=0; auctionEnded=false; save(); toast("All data cleared"); home(); })
                .setNegativeButton("Cancel", null).show();
    }

    void exportPdf() {
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Js Auctions").replace(" ", "_") + "_Teams.pdf");
            startActivityForResult(i, 7);
        } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
    }

    void writePdf(Uri uri) {
        try {
            PdfDocument pdf = new PdfDocument();
            Paint paint = new Paint();
            paint.setColor(Color.BLACK); paint.setTextSize(18); paint.setFakeBoldText(true);
            int pageNo = 1, y = 40;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, pageNo).create());
            Canvas c = page.getCanvas();
            c.drawText("J's Auction Manager - " + sp.getString("auctionName", "KPL Season 1"), 30, y, paint); y += 30;
            paint.setTextSize(11); paint.setFakeBoldText(false);
            c.drawText("Owned by Team RDB | Creator: Josco | Copyright 2026 Team RDB", 30, y, paint); y += 30;
            for (int t = 0; t < teams.length(); t++) {
                if (y > 780) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c = page.getCanvas(); y = 40; }
                JSONObject team = teams.getJSONObject(t); String tn = team.optString("name");
                paint.setTextSize(15); paint.setFakeBoldText(true); c.drawText(tn + "  Players: " + teamCount(tn) + "/" + totalSlots() + "  Spent: " + teamSpent(tn) + "  Balance: " + teamBalance(tn), 30, y, paint); y += 24;
                paint.setTextSize(10); paint.setFakeBoldText(true); c.drawText("Player",30,y,paint); c.drawText("Role",170,y,paint); c.drawText("Bat",300,y,paint); c.drawText("Bowl",390,y,paint); c.drawText("Bid",520,y,paint); y += 16;
                paint.setFakeBoldText(false);
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (!tn.equals(p.optString("team"))) continue;
                    if (y > 800) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c = page.getCanvas(); y = 40; }
                    c.drawText(cut(p.optString("name"),22),30,y,paint); c.drawText(cut(p.optString("role"),18),170,y,paint); c.drawText(cut(p.optString("bat"),13),300,y,paint); c.drawText(cut(p.optString("bowl"),18),390,y,paint); c.drawText(String.valueOf(p.optInt("bid")),520,y,paint); y += 15;
                }
                y += 18;
            }
            pdf.finishPage(page);
            OutputStream os = getContentResolver().openOutputStream(uri);
            pdf.writeTo(os); os.close(); pdf.close(); toast("PDF exported");
        } catch (Exception e) { toast("PDF failed: " + e.toString()); }
    }

    String cut(String s, int n) { return s == null ? "" : (s.length() <= n ? s : s.substring(0,n-1)); }

    public void onBackPressed() { home(); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    public class StadiumBackdrop extends View {
        Paint p = new Paint(1);
        public StadiumBackdrop(android.content.Context c) { super(c); }
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 255, 255, 255));
            for (int i = 0; i < 6; i++) {
                float x = (w / 7f) * (i + 1);
                p.setColor(Color.argb(70, 255, 230, 150));
                c.drawCircle(x, h * 0.16f, 24, p);
                p.setStrokeWidth(3);
                p.setColor(Color.argb(38, 244, 184, 62));
                c.drawLine(x, h * 0.16f, w/2f, h*0.52f, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 177, 36, 47));
            c.drawOval(-w*0.15f, h*0.72f, w*1.15f, h*1.10f, p);
            p.setColor(Color.argb(110, 12, 95, 62));
            c.drawOval(-w*0.05f, h*0.77f, w*1.05f, h*1.03f, p);
            p.setColor(Color.argb(120, 244, 184, 62));
            p.setStrokeWidth(5);
            p.setStyle(Paint.Style.STROKE);
            c.drawOval(w*0.10f, h*0.80f, w*0.90f, h*0.98f, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(54);
            p.setColor(Color.argb(28, 255, 255, 255));
            c.drawText("CRICKET AUCTION", w*0.08f, h*0.92f, p);
        }
    }

}
