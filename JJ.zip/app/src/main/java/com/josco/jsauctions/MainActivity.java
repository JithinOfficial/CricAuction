package com.josco.jsauctions;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation;
import android.os.Environment;
import java.io.OutputStream;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    // RDB cricket theme: deep navy + maroon + stadium gold.
    int bg = Color.rgb(4, 10, 22);
    int panel = Color.rgb(12, 24, 42);
    int panel2 = Color.rgb(18, 38, 62);
    int gold = Color.rgb(244, 184, 62);
    int blue = Color.rgb(36, 159, 184);
    int green = Color.rgb(22, 148, 104);
    int red = Color.rgb(177, 36, 47);
    int orange = Color.rgb(218, 112, 42);
    int text = Color.rgb(246, 248, 252);
    int muted = Color.rgb(190, 202, 216);

    LinearLayout root;
    SharedPreferences sp;
    JSONArray players = new JSONArray();
    JSONArray teams = new JSONArray();
    JSONArray deck = new JSONArray();
    JSONArray fixtures = new JSONArray();
    int currentIndex = -1;
    String pickTarget = "";
    String pdfMode = "ALL";
    String pdfTeam = "";
    int editingTeamIndex = -1;
    int roundNo = 0;
    boolean auctionEnded = false;

    String[] roles = {"Batsman", "Bowler", "All Rounder", "Wicket Keeper Batsman"};
    String[] bats = {"Right hand bat", "Left hand bat"};
    String[] bowls = {"Right arm fast", "Right arm medium", "Right arm off spin", "Right arm leg spin", "Left arm fast", "Left arm medium", "Left arm orthodox", "Left arm wrist spin", "None"};

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("db", 0);
        setDefaults();
        load();
        intro();
    }

    void setDefaults() {
        if (!sp.contains("playersPerTeam")) {
            sp.edit()
                    .putInt("playersPerTeam", 11)
                    .putBoolean("bench", false)
                    .putInt("benchCount", 2)
                    .putInt("maxBucket", 11000)
                    .putInt("basePoints", 300)
                    .putString("increments", "300-999:50\n1000-2999:100\n3000-99999:250")
                    .putString("auctionName", "KPL Season 1")
                    .putBoolean("auctionEnded", false)
                    .putInt("roundNo", 0)
                    .putInt("poolCount", 2)
                    .putString("fixtures", "[]")
                    .apply();
        }
    }

    void load() {
        try {
            players = new JSONArray(sp.getString("players", "[]"));
            teams = new JSONArray(sp.getString("teams", "[]"));
            deck = new JSONArray(sp.getString("deck", "[]"));
            fixtures = new JSONArray(sp.getString("fixtures", "[]"));
            currentIndex = sp.getInt("idx", -1);
            roundNo = sp.getInt("roundNo", 0);
            auctionEnded = sp.getBoolean("auctionEnded", false);
            ensurePlayerIds();
        } catch (Exception e) { }
    }

    void save() {
        sp.edit().putString("players", players.toString()).putString("teams", teams.toString()).putString("deck", deck.toString()).putString("fixtures", fixtures.toString()).putInt("idx", currentIndex).putInt("roundNo", roundNo).putBoolean("auctionEnded", auctionEnded).apply();
    }

    GradientDrawable bgShape(int color, int strokeColor, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (stroke > 0) g.setStroke(stroke, strokeColor);
        return g;
    }

    String cleanRole(String role) {
        if (role == null) return "";
        return role.replace("🏏", "").replace("⚡", "").replace("⭐", "").replace("🧤", "").trim();
    }



    String nextPlayerId() {
        int max = 0;
        try {
            for (int i = 0; i < players.length(); i++) {
                String id = players.getJSONObject(i).optString("pid", "").replaceAll("[^0-9]", "");
                if (id.length() > 0) {
                    int n = Integer.parseInt(id);
                    if (n > max) max = n;
                }
            }
        } catch (Exception e) { }
        return String.format(java.util.Locale.US, "%02d", max + 1);
    }

    void ensurePlayerIds() {
        try {
            boolean changed = false;
            for (int i = 0; i < players.length(); i++) {
                JSONObject pl = players.getJSONObject(i);
                if (pl.optString("pid", "").trim().length() == 0) {
                    pl.put("pid", nextPlayerId());
                    changed = true;
                }
            }
            if (changed) sp.edit().putString("players", players.toString()).apply();
        } catch (Exception e) { }
    }

    void footer() {
        TextView f = tv("Owned by Team RDB • Creator: Josco\n© 2026 Team RDB. All rights reserved. This application, auction workflow, UI concepts, data structure and tournament management system are proprietary work of Team RDB. Unauthorized reproduction, redistribution, reverse engineering or commercial reuse is prohibited.", 12, Color.LTGRAY);
        f.setGravity(Gravity.CENTER);
        f.setPadding(12, 28, 12, 12);
        root.addView(f);
    }

    int totalSlots() { return sp.getInt("playersPerTeam", 11) + (sp.getBoolean("bench", false) ? sp.getInt("benchCount", 2) : 0); }
    int maxBucket() { return sp.getInt("maxBucket", 11000); }
    int basePoints() { return sp.getInt("basePoints", 300); }

    TextView tv(String s, int size, int c) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(c);
        v.setPadding(18, 10, 18, 10);
        return v;
    }

    TextView label(String s) {
        TextView v = tv(s, 14, muted);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    TextView title(String s) {
        TextView v = tv(s, 24, gold);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    GradientDrawable buttonShape(int color) {
        int end = darken(color, 42);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{color, end});
        g.setCornerRadius(30);
        g.setStroke(2, Color.argb(190, 244, 184, 62));
        return g;
    }

    int darken(int c, int amount) {
        return Color.rgb(Math.max(0, Color.red(c)-amount), Math.max(0, Color.green(c)-amount), Math.max(0, Color.blue(c)-amount));
    }

    Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(text);
        b.setShadowLayer(3, 0, 1, Color.BLACK);
        b.setBackground(buttonShape(color));
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(20, 16, 20, 16);
        return b;
    }

    void addBtn(String s, int color, View.OnClickListener l) {
        Button b = btn(s, color);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        root.addView(b, lp);
    }

    LinearLayout cardBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16, 16, 16, 16);
        box.setBackground(bgShape(panel, Color.rgb(67, 85, 130), 26, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 10, 0, 12);
        root.addView(box, lp);
        return box;
    }


    void intro() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(28, 28, 28, 28);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(2, 5, 14), Color.rgb(24, 6, 18), Color.rgb(4, 17, 30)});
        wrap.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(gd);
        frame.addView(new StadiumBackdrop(this), new FrameLayout.LayoutParams(-1, -1));
        frame.addView(wrap, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("rdblogo", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(320, 320);
        ilp.setMargins(0, 0, 0, 20);
        wrap.addView(logo, ilp);

        TextView app = title("J's Auction Manager");
        app.setTextSize(32);
        app.setTextColor(gold);
        app.setShadowLayer(10, 0, 0, Color.rgb(160, 35, 45));
        wrap.addView(app);

        TextView tag = tv("Premium Cricket Auction Manager", 18, text);
        tag.setGravity(Gravity.CENTER);
        tag.setTypeface(Typeface.DEFAULT_BOLD);
        wrap.addView(tag);

        TextView own = tv("Owned By Team RDB", 16, gold);
        own.setGravity(Gravity.CENTER);
        wrap.addView(own);

        TextView cr = tv("Created By Josco", 15, muted);
        cr.setGravity(Gravity.CENTER);
        wrap.addView(cr);

        animateIn(logo, 0);
        animateIn(app, 350);
        animateIn(tag, 700);
        animateIn(own, 1050);
        animateIn(cr, 1350);

        new Handler().postDelayed(new Runnable() { public void run() { home(); } }, 3300);
    }

    void animateIn(View v, long delay) {
        v.setAlpha(0f);
        v.setTranslationY(50f);
        v.animate().alpha(1f).translationY(0f).setDuration(850).setStartDelay(delay).start();
    }

    void base(String screenTitle) {
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 24, 18, 24);
        root.setBackgroundColor(bg);
        sv.addView(root);
        setContentView(sv);
        TextView h = title("J's Auction Manager");
        root.addView(h);
        if (screenTitle != null && screenTitle.trim().length() > 0) {
            TextView sub = tv(screenTitle, 14, muted);
            sub.setGravity(Gravity.CENTER);
            root.addView(sub);
        }
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(text);
        e.setHintTextColor(muted);
        e.setSingleLine(false);
        e.setBackground(bgShape(panel2, Color.rgb(80, 100, 150), 18, 1));
        e.setPadding(16, 10, 16, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(e, lp);
        return e;
    }

    Spinner spin(String[] arr) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arr) { public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; } public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }};
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    boolean teamHasIcon(String teamName) {
        try {
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if (teamName.equals(p.optString("team")) && "ICON".equals(p.optString("status"))) return true;
            }
        } catch (Exception e) { }
        return false;
    }

    Spinner teamSpinner(boolean includeEmptyMessage) {
        return teamSpinnerInternal(includeEmptyMessage, false);
    }

    Spinner iconAvailableTeamSpinner(boolean includeEmptyMessage) {
        return teamSpinnerInternal(includeEmptyMessage, true);
    }

    Spinner teamSpinnerInternal(boolean includeEmptyMessage, boolean onlyTeamsWithoutIcon) {
        ArrayList<String> list = new ArrayList<String>();
        try {
            for (int i = 0; i < teams.length(); i++) {
                String tn = teams.getJSONObject(i).optString("name");
                if (onlyTeamsWithoutIcon && teamHasIcon(tn)) continue;
                list.add(tn);
            }
        } catch (Exception e) { }
        if (list.size() == 0 && includeEmptyMessage) {
            list.add(onlyTeamsWithoutIcon && teams.length() > 0 ? "All teams already have icon player" : "No teams added");
        }
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {
            public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; }
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    void home() {
        base("");
        LinearLayout hero = cardBox();
        hero.setBackground(bgShape(Color.rgb(13, 24, 43), gold, 34, 2));
        hero.addView(tv("🏟️  " + sp.getString("auctionName", "KPL Season 1"), 24, gold));
        hero.addView(tv("Teams Registered: " + teams.length(), 16, text));
        hero.addView(tv("Players Registered: " + players.length(), 16, text));
        hero.addView(tv("Current Round: " + roundNo, 15, muted));
        addBtn("➕ Add Player", blue, v -> playerForm());
        addBtn("🛡️ Add Franchisee / Team", red, v -> teamForm());
        addBtn("🎙️ Start / Continue Auction", green, v -> auction());
        addBtn("📋 Teams, Logos & Squads", blue, v -> teamsView());
        addBtn("🔁 Unsold / Recall Buckets", orange, v -> buckets());
        addBtn("⚙️ Auction Settings", red, v -> settings());
        addBtn("⭐ Change Icon Player", gold, v -> changeIconScreen());
        addBtn("🏟️ Pools & Fixtures", orange, v -> fixturesSetup());
        addBtn("📄 Export All Teams PDF", green, v -> exportPdf());
        addBtn("📄 Export Separate Team PDF", blue, v -> exportTeamPdfScreen());
        addBtn("📘 Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
        addBtn("🧾 Player Catalogue PDF Settings", blue, v -> playerCatalogueSettings());
        addBtn("📅 Export Fixtures PDF", orange, v -> exportFixturesPdf());
        footer();
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, 5);
    }

    public void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 5 && c == RESULT_OK && d != null) {
            Uri u = d.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
            SharedPreferences.Editor ed = sp.edit();
            if ("photo".equals(pickTarget)) ed.putString("last_photo", u.toString());
            else if ("id".equals(pickTarget)) ed.putString("last_id", u.toString());
            else if ("teamLogo".equals(pickTarget)) ed.putString("last_team_logo", u.toString());
            ed.apply();
            toast("Image selected. Now press Save.");
        }
        if (r == 7 && c == RESULT_OK && d != null) {
            writePdf(d.getData());
        }
    }

    void playerForm() {
        base("Add Player");
        root.addView(label("Player name"));
        EditText name = input("Example: Sanju Samson");
        root.addView(label("Place"));
        EditText place = input("Example: Thrissur");
        root.addView(label("Mobile number"));
        EditText mobile = input("Example: 9876543210");
        mobile.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(label("Player role"));
        Spinner role = spin(roles);
        root.addView(label("Batting style"));
        Spinner bat = spin(bats);
        root.addView(label("Bowling style"));
        Spinner bowl = spin(bowls);
        CheckBox iconCb = new CheckBox(this);
        iconCb.setText("Mark as Icon Player - directly assign to a team, not auctioned");
        iconCb.setTextColor(text);
        iconCb.setPadding(8, 8, 8, 8);
        root.addView(iconCb);
        root.addView(label("Icon player team"));
        Spinner iconTeam = iconAvailableTeamSpinner(true);
        addBtn("Upload Player Photo", blue, v -> { pickTarget = "photo"; pickImage(); });
        addBtn("Upload Aadhaar / ID Photo", orange, v -> { pickTarget = "id"; pickImage(); });
        addBtn("Save Player", green, v -> {
            try {
                if (name.getText().toString().trim().length() == 0) { toast("Enter player name"); return; }
                ensurePlayerIds();
                JSONObject o = new JSONObject();
                o.put("pid", nextPlayerId());
                o.put("name", name.getText().toString().trim());
                o.put("place", place.getText().toString().trim());
                o.put("mobile", mobile.getText().toString().trim());
                o.put("role", role.getSelectedItem().toString());
                o.put("bat", bat.getSelectedItem().toString());
                o.put("bowl", bowl.getSelectedItem().toString());
                o.put("photo", sp.getString("last_photo", ""));
                o.put("idp", sp.getString("last_id", ""));
                if (iconCb.isChecked()) {
                    String it = iconTeam.getSelectedItem() == null ? "" : iconTeam.getSelectedItem().toString();
                    if (it.length() == 0 || "No teams added".equals(it) || "All teams already have icon player".equals(it)) { toast("No available team for new icon. Use Change Icon Player to replace an existing icon."); return; }
                    o.put("status", "ICON");
                    o.put("team", it);
                    o.put("bid", 0);
                } else {
                    o.put("status", "NEW");
                    o.put("team", "");
                    o.put("bid", 0);
                }
                players.put(o);
                sp.edit().remove("last_photo").remove("last_id").apply();
                save();
                toast("Player saved");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    void teamForm() {
        base("Add Franchisee / Team");
        root.addView(label("Team / franchisee name"));
        EditText n = input("Example: RDB");
        addBtn("Upload Team Logo", blue, v -> { pickTarget = "teamLogo"; pickImage(); });
        addBtn("Save Team", green, v -> {
            try {
                if (n.getText().toString().trim().length() == 0) { toast("Enter team name"); return; }
                JSONObject o = new JSONObject();
                o.put("name", n.getText().toString().trim());
                o.put("logo", sp.getString("last_team_logo", ""));
                o.put("pool", "Pool A");
                teams.put(o);
                sp.edit().remove("last_team_logo").apply();
                save();
                toast("Team saved");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    int teamCount(String t) throws Exception {
        int c = 0;
        for (int i = 0; i < players.length(); i++) if (t.equals(players.getJSONObject(i).optString("team"))) c++;
        return c;
    }

    int teamSpent(String t) throws Exception {
        int spent = 0;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.getJSONObject(i);
            if (t.equals(p.optString("team"))) spent += p.optInt("bid", 0);
        }
        return spent;
    }

    int teamBalance(String t) throws Exception { return maxBucket() - teamSpent(t); }

    int maxBidForTeam(String t) throws Exception {
        int bought = teamCount(t);
        int slots = totalSlots();
        if (bought >= slots) return 0;
        int balance = teamBalance(t);
        int reserveAfterCurrentBuy = (slots - bought - 1) * basePoints();
        int maxBid = balance - reserveAfterCurrentBuy;
        return Math.max(0, maxBid);
    }

    int nextIncrementFor(int bid) {
        String cfg = sp.getString("increments", "300-999:50\n1000-2999:100\n3000-99999:250");
        String[] lines = cfg.split("\\n");
        for (String line : lines) {
            try {
                line = line.trim();
                if (line.length() == 0 || !line.contains(":")) continue;
                String[] lrInc = line.split(":");
                String[] lr = lrInc[0].split("-");
                int low = Integer.parseInt(lr[0].trim());
                int high = Integer.parseInt(lr[1].trim());
                int inc = Integer.parseInt(lrInc[1].trim());
                if (bid >= low && bid <= high) return inc;
            } catch (Exception e) { }
        }
        return 100;
    }

    void showTeamPoints() {
        try {
            LinearLayout box = cardBox();
            box.addView(tv("Live Bucket Table", 20, gold));
            HorizontalScrollView hsv = new HorizontalScrollView(this);
            TableLayout table = new TableLayout(this);
            table.setStretchAllColumns(true);
            table.addView(row(new String[]{"TEAM", "SQUAD", "SPENT", "BALANCE", "MAX BID", "NEXT INC"}, true));
            for (int i = 0; i < teams.length(); i++) {
                String tn = teams.getJSONObject(i).optString("name");
                int mb = maxBidForTeam(tn);
                table.addView(row(new String[]{tn, teamCount(tn)+"/"+totalSlots(), String.valueOf(teamSpent(tn)), String.valueOf(teamBalance(tn)), String.valueOf(mb), String.valueOf(nextIncrementFor(Math.max(basePoints(), mb)))}, false));
            }
            hsv.addView(table);
            box.addView(hsv);
        } catch (Exception e) { }
    }

    TableRow row(String[] vals, boolean header) {
        TableRow tr = new TableRow(this);
        tr.setBackgroundColor(header ? Color.rgb(76, 55, 10) : panel2);
        for (String v : vals) {
            TextView cell = tv(v, header ? 13 : 14, header ? gold : text);
            cell.setTypeface(Typeface.DEFAULT_BOLD);
            cell.setPadding(18, 14, 18, 14);
            tr.addView(cell);
        }
        return tr;
    }

    void newRound() {
        try {
            ArrayList<Integer> ids = new ArrayList<Integer>();
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                String st = p.optString("status", "NEW");
                if ("SOLD".equals(st)) continue;
                if (roundNo == 0 && "NEW".equals(st)) ids.add(i);
                else if (roundNo > 0 && ("UNSOLD".equals(st) || "RECALL".equals(st))) ids.add(i);
            }
            if (ids.size() == 0 && roundNo == 0) {
                for (int i = 0; i < players.length(); i++) if (!"SOLD".equals(players.getJSONObject(i).optString("status"))) ids.add(i);
            }
            Collections.shuffle(ids);
            deck = new JSONArray();
            for (int x : ids) deck.put(x);
            currentIndex = ids.size() == 0 ? -1 : 0;
            if (ids.size() > 0) roundNo++;
            auctionEnded = false;
            save();
        } catch (Exception e) { }
    }

    ArrayList<String> availableTeams() throws Exception {
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < teams.length(); i++) {
            String tn = teams.getJSONObject(i).optString("name");
            if (teamCount(tn) < totalSlots()) names.add(tn);
        }
        return names;
    }

    void auction() {
        base("Auction Room");
        showTeamPoints();
        if (auctionEnded) {
            root.addView(tv("Auction ended manually. You can export PDF or reset auction status from Settings.", 18, gold));
            addBtn("Export All Teams PDF", green, v -> exportPdf());
        addBtn("Export Selected Team PDF", blue, v -> exportTeamPdfScreen());
            addBtn("Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (players.length() == 0 || teams.length() == 0) {
            root.addView(tv("Add players and franchisees first.", 18, text));
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (allSoldOrFull()) {
            root.addView(tv("Auction completed or all teams are full.", 20, green));
            addBtn("Teams & Players", blue, v -> teamsView());
            addBtn("Back", panel2, v -> home());
            return;
        }
        if (deck.length() == 0 || currentIndex < 0 || currentIndex >= deck.length()) {
            LinearLayout info = cardBox();
            info.addView(tv(roundNo == 0 ? "Start First Round" : "Start Next Unsold/Recall Round", 22, gold));
            info.addView(tv("Round rules: First round displays every NEW player once in random order. Next rounds use only UNSOLD + RECALL players, randomly once each. SOLD players never return.", 15, text));
            addBtn(roundNo == 0 ? "Start First Random Round" : "Start Next Round", green, v -> { newRound(); auction(); });
            addBtn("End Auction", red, v -> { auctionEnded = true; save(); home(); });
            addBtn("Back", panel2, v -> home());
            return;
        }
        try {
            int pi = deck.getInt(currentIndex);
            JSONObject p = players.getJSONObject(pi);
            LinearLayout box = cardBox();
            box.addView(tv("Auction Card " + (currentIndex + 1) + " / " + deck.length(), 15, gold));
            ImageView iv = new ImageView(this);
            String ph = p.optString("photo", "");
            if (ph.length() > 0) iv.setImageURI(Uri.parse(ph));
            else iv.setBackgroundColor(panel2);
            iv.setAdjustViewBounds(true);
            iv.setMaxHeight(560);
            box.addView(iv, new LinearLayout.LayoutParams(-1, -2));
            box.addView(tv(p.optString("name"), 29, text));
            box.addView(tv("Role: " + cleanRole(p.optString("role")) + "\nBatting: " + p.optString("bat") + "\nBowling: " + p.optString("bowl") + "\nBase Points: " + basePoints(), 16, Color.LTGRAY));

            root.addView(label("Sold to team"));
            ArrayList<String> ok = availableTeams();
            Spinner ts = new Spinner(this);
            ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ok) { public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; } public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }};
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            ts.setAdapter(ad);
            root.addView(ts);

            root.addView(label("Sold bid value / bucket points"));
            EditText bid = input("Enter final bid points");
            bid.setInputType(InputType.TYPE_CLASS_NUMBER);
            bid.setText(String.valueOf(basePoints()));

            TextView hint = tv("Select a team to view max bid.", 14, Color.LTGRAY);
            root.addView(hint);
            ts.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                public void onItemSelected(android.widget.AdapterView<?> parent, View view, int pos, long id) {
                    try {
                        String tn = parent.getItemAtPosition(pos).toString();
                        int mb = maxBidForTeam(tn);
                        hint.setText(tn + " can bid up to " + mb + ". Increment at current bid: " + nextIncrementFor(toInt(bid.getText().toString(), basePoints())));
                    } catch (Exception e) { }
                }
                public void onNothingSelected(android.widget.AdapterView<?> parent) { }
            });

            addBtn("SOLD - Add to Selected Team", green, v -> {
                try {
                    if (ts.getCount() == 0) { toast("All teams are full"); return; }
                    String tn = ts.getSelectedItem().toString();
                    int val = toInt(bid.getText().toString(), 0);
                    if (val < basePoints()) { toast("Bid cannot be below base points"); return; }
                    int max = maxBidForTeam(tn);
                    if (val > max) { toast("Bid exceeds max allowed for " + tn + ": " + max); return; }
                    JSONObject pp = players.getJSONObject(pi);
                    pp.put("status", "SOLD");
                    pp.put("team", tn);
                    pp.put("bid", val);
                    next();
                } catch (Exception e) { toast(e.toString()); }
            });
            addBtn("UNSOLD - Move to Unsold Bucket", red, v -> mark(pi, "UNSOLD"));
            addBtn("RECALL - Move to Recall Bucket", orange, v -> mark(pi, "RECALL"));
            addBtn("End Auction", red, v -> { auctionEnded = true; save(); home(); });
            addBtn("Back", panel2, v -> home());
        } catch (Exception e) {
            root.addView(tv(e.toString(), 14, red));
        }
    }

    int toInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    boolean allSoldOrFull() {
        try {
            boolean anyUnsold = false;
            for (int i = 0; i < players.length(); i++) { String st = players.getJSONObject(i).optString("status"); if (!"SOLD".equals(st) && !"ICON".equals(st)) anyUnsold = true; }
            if (!anyUnsold) return true;
            boolean anyTeamSlot = false;
            for (int i = 0; i < teams.length(); i++) if (teamCount(teams.getJSONObject(i).optString("name")) < totalSlots()) anyTeamSlot = true;
            return !anyTeamSlot;
        } catch (Exception e) { return false; }
    }

    void mark(int i, String s) {
        try {
            players.getJSONObject(i).put("status", s);
            players.getJSONObject(i).put("team", "");
            players.getJSONObject(i).put("bid", 0);
            next();
        } catch (Exception e) { }
    }

    void next() {
        currentIndex++;
        save();
        if (currentIndex >= deck.length()) {
            deck = new JSONArray();
            currentIndex = -1;
            save();
            toast("Round completed");
        }
        auction();
    }

    void teamsView() {
        base("Teams & Squads");
        try {
            root.addView(tv("Squad slots: " + totalSlots() + " | Max bucket: " + maxBucket() + " | Base: " + basePoints(), 15, gold));
            for (int t = 0; t < teams.length(); t++) {
                JSONObject team = teams.getJSONObject(t);
                String tn = team.optString("name");
                LinearLayout box = cardBox();
                String logo = team.optString("logo", "");
                if (logo.length() > 0) {
                    ImageView iv = new ImageView(this);
                    iv.setImageURI(Uri.parse(logo));
                    iv.setAdjustViewBounds(true);
                    iv.setMaxHeight(220);
                    box.addView(iv);
                }
                box.addView(tv(tn + "  (" + teamCount(tn) + "/" + totalSlots() + ")", 22, gold));
                box.addView(tv("Spent: " + teamSpent(tn) + " | Balance: " + teamBalance(tn) + " | Max Bid: " + maxBidForTeam(tn), 14, text));
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (tn.equals(p.optString("team"))) { String tag = "ICON".equals(p.optString("status")) ? " 👑 ICON" : ""; box.addView(tv("• " + p.optString("name") + tag + " - " + cleanRole(p.optString("role")) + " - " + p.optInt("bid") + " pts", 15, Color.LTGRAY)); }
                }
                final int delIndex = t;
                Button db = btn("Delete " + tn, red);
                db.setOnClickListener(v -> confirmDeleteTeam(delIndex));
                box.addView(db);
            }
        } catch (Exception e) { root.addView(tv(e.toString(), 14, red)); }
        addBtn("Export All Teams PDF", green, v -> exportPdf());
        addBtn("Export Selected Team PDF", blue, v -> exportTeamPdfScreen());
        addBtn("Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
        addBtn("Back", panel2, v -> home());
    }

    void confirmDeleteTeam(int idx) {
        try {
            String tn = teams.getJSONObject(idx).optString("name");
            new AlertDialog.Builder(this).setTitle("Delete team?").setMessage("Delete " + tn + "? Sold players in this team will be moved to RECALL bucket and their bid will be cleared.")
                    .setPositiveButton("Delete", (d,w) -> deleteTeam(idx))
                    .setNegativeButton("Cancel", null).show();
        } catch (Exception e) { toast(e.toString()); }
    }

    void deleteTeam(int idx) {
        try {
            String tn = teams.getJSONObject(idx).optString("name");
            JSONArray nt = new JSONArray();
            for (int i = 0; i < teams.length(); i++) if (i != idx) nt.put(teams.getJSONObject(i));
            teams = nt;
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if (tn.equals(p.optString("team"))) { p.put("team", ""); p.put("bid", 0); p.put("status", "RECALL"); }
            }
            deck = new JSONArray(); currentIndex = -1; save(); toast("Team deleted"); teamsView();
        } catch (Exception e) { toast(e.toString()); }
    }

    void buckets() {
        base("Unsold / Recall Buckets");
        try {
            LinearLayout u = cardBox();
            u.addView(tv("UNSOLD", 22, red));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if ("UNSOLD".equals(p.optString("status"))) u.addView(tv("• " + p.optString("name") + " | " + p.optString("role") + " | Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 15, text));
            }
            LinearLayout r = cardBox();
            r.addView(tv("RECALL", 22, orange));
            for (int i = 0; i < players.length(); i++) {
                JSONObject p = players.getJSONObject(i);
                if ("RECALL".equals(p.optString("status"))) r.addView(tv("• " + p.optString("name") + " | " + p.optString("role") + " | Bat: " + p.optString("bat") + " | Bowl: " + p.optString("bowl"), 15, text));
            }
        } catch (Exception e) { }
        addBtn("Back", panel2, v -> home());
    }


    Spinner playerSpinner(boolean includeAll) {
        ArrayList<String> list = new ArrayList<String>();
        try { for (int i = 0; i < players.length(); i++) list.add(players.getJSONObject(i).optString("name")); } catch (Exception e) { }
        if (list.size() == 0) list.add("No players added");
        return customSpinner(list);
    }

    Spinner customSpinner(ArrayList<String> list) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {
            public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(text); v.setTextSize(16); v.setPadding(18, 12, 18, 12); return v; }
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) { TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(text); v.setBackgroundColor(panel2); v.setPadding(18, 16, 18, 16); return v; }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 6, 0, 12);
        root.addView(s, lp);
        return s;
    }

    void changeIconScreen() {
        base("Change Icon Player");
        if (players.length() == 0 || teams.length() == 0) { root.addView(tv("Add players and teams first.", 18, text)); addBtn("Back", panel2, v -> home()); return; }
        LinearLayout info = cardBox();
        info.addView(tv("Icon players are directly assigned to a franchise, excluded from auction rounds, and counted in squad size/max bid reserve.", 15, text));
        root.addView(label("Select player"));
        Spinner ps = playerSpinner(true);
        root.addView(label("Assign as icon to team"));
        Spinner ts = teamSpinner(false);
        addBtn("Set / Change Icon", green, v -> {
            try {
                String pn = ps.getSelectedItem() == null ? "" : ps.getSelectedItem().toString();
                String tn = ts.getSelectedItem() == null ? "" : ts.getSelectedItem().toString();
                if (pn.startsWith("No ") || tn.length()==0) { toast("Select valid player/team"); return; }
                for (int i=0;i<players.length();i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (tn.equals(p.optString("team")) && "ICON".equals(p.optString("status"))) { p.put("status", "NEW"); p.put("team", ""); p.put("bid", 0); }
                }
                for (int i=0;i<players.length();i++) {
                    JSONObject p = players.getJSONObject(i);
                    if (pn.equals(p.optString("name"))) { p.put("status", "ICON"); p.put("team", tn); p.put("bid", 0); }
                }
                deck = new JSONArray(); currentIndex = -1; save(); toast("Icon player updated"); home();
            } catch(Exception e) { toast(e.toString()); }
        });
        addBtn("Remove All Icons", red, v -> { try { for(int i=0;i<players.length();i++){ JSONObject p=players.getJSONObject(i); if("ICON".equals(p.optString("status"))){ p.put("status","NEW"); p.put("team",""); p.put("bid",0); } } deck=new JSONArray(); currentIndex=-1; save(); toast("Icons removed"); home(); } catch(Exception e){toast(e.toString());} });
        addBtn("Back", panel2, v -> home());
    }

    String poolName(int i) { return "Pool " + (char)('A' + i); }

    Spinner poolSpinner(String selected, int count) {
        ArrayList<String> list = new ArrayList<String>();
        for (int i=0;i<count;i++) list.add(poolName(i));
        Spinner s = customSpinner(list);
        for (int i=0;i<list.size();i++) if (list.get(i).equals(selected)) s.setSelection(i);
        return s;
    }

    void fixturesSetup() {
        base("Pools & Fixtures");
        int pc = Math.max(1, sp.getInt("poolCount", 2));
        LinearLayout guide = cardBox();
        guide.addView(tv("Create pools, assign each franchise to one pool only, then generate pool matches and knockout placeholders. Export fixtures as a styled PDF.", 15, text));
        root.addView(label("Number of pools"));
        EditText pcInput = input("2"); pcInput.setInputType(InputType.TYPE_CLASS_NUMBER); pcInput.setText(String.valueOf(pc));
        addBtn("Apply Pool Count", blue, v -> { sp.edit().putInt("poolCount", Math.max(1, toInt(pcInput.getText().toString(), 2))).apply(); fixturesSetup(); });

        final ArrayList<Spinner> poolSpinners = new ArrayList<Spinner>();
        for (int i=0;i<teams.length();i++) {
            try {
                JSONObject tm = teams.getJSONObject(i);
                root.addView(label(tm.optString("name") + " pool"));
                poolSpinners.add(poolSpinner(tm.optString("pool", "Pool A"), pc));
            } catch(Exception e) { }
        }
        CheckBox cross = new CheckBox(this); cross.setText("Cross-pool league: teams play against teams from other pools"); cross.setTextColor(text); cross.setChecked(sp.getBoolean("crossPool", true)); root.addView(cross);
        CheckBox ipl = new CheckBox(this); ipl.setText("IPL style full league: every team plays every other team"); ipl.setTextColor(text); ipl.setChecked(sp.getBoolean("iplStyle", false)); root.addView(ipl);
        root.addView(label("Start time HH:mm")); EditText start = input("08:00"); start.setText(sp.getString("fixtureStart", "08:00"));
        root.addView(label("Minutes for one match")); EditText dur = input("30"); dur.setInputType(InputType.TYPE_CLASS_NUMBER); dur.setText(String.valueOf(sp.getInt("matchMinutes", 30)));
        root.addView(label("Gap between matches in minutes")); EditText gap = input("10"); gap.setInputType(InputType.TYPE_CLASS_NUMBER); gap.setText(String.valueOf(sp.getInt("gapMinutes", 10)));
        root.addView(label("Qualifiers from each pool")); EditText qual = input("2"); qual.setInputType(InputType.TYPE_CLASS_NUMBER); qual.setText(String.valueOf(sp.getInt("qualifiers", 2)));
        CheckBox qf = new CheckBox(this); qf.setText("Include Quarter Finals if qualifiers are more than 4"); qf.setTextColor(text); qf.setChecked(sp.getBoolean("includeQF", true)); root.addView(qf);
        CheckBox semi = new CheckBox(this); semi.setText("Include Semi Finals"); semi.setTextColor(text); semi.setChecked(sp.getBoolean("includeSemi", true)); root.addView(semi);
        CheckBox fin = new CheckBox(this); fin.setText("Include Final"); fin.setTextColor(text); fin.setChecked(sp.getBoolean("includeFinal", true)); root.addView(fin);
        CheckBox losers = new CheckBox(this); losers.setText("Include Losers Final / 3rd Place Match"); losers.setTextColor(text); losers.setChecked(sp.getBoolean("includeLosers", false)); root.addView(losers);
        addBtn("Save Pools & Generate Fixtures", green, v -> {
            try {
                for (int i=0;i<teams.length();i++) teams.getJSONObject(i).put("pool", poolSpinners.get(i).getSelectedItem().toString());
                sp.edit().putInt("poolCount", Math.max(1,toInt(pcInput.getText().toString(),2))).putBoolean("crossPool", cross.isChecked()).putBoolean("iplStyle", ipl.isChecked()).putString("fixtureStart", start.getText().toString().trim()).putInt("matchMinutes", Math.max(1,toInt(dur.getText().toString(),30))).putInt("gapMinutes", Math.max(0,toInt(gap.getText().toString(),10))).putInt("qualifiers", Math.max(1,toInt(qual.getText().toString(),2))).putBoolean("includeQF", qf.isChecked()).putBoolean("includeSemi", semi.isChecked()).putBoolean("includeFinal", fin.isChecked()).putBoolean("includeLosers", losers.isChecked()).apply();
                generateFixtures(cross.isChecked(), ipl.isChecked(), sp.getInt("poolCount",2), sp.getString("fixtureStart","08:00"), sp.getInt("matchMinutes",30), sp.getInt("gapMinutes",10), sp.getInt("qualifiers",2), qf.isChecked(), semi.isChecked(), fin.isChecked(), losers.isChecked());
                save(); toast("Fixtures generated"); fixturesView();
            } catch(Exception e) { toast(e.toString()); }
        });
        addBtn("View Fixtures", blue, v -> fixturesView());
        addBtn("Export Fixtures PDF", orange, v -> exportFixturesPdf());
        addBtn("Back", panel2, v -> home());
    }

    int parseTime(String hhmm) {
        try { String[] p = hhmm.split(":"); return Integer.parseInt(p[0].trim())*60 + Integer.parseInt(p[1].trim()); } catch(Exception e) { return 8*60; }
    }
    String fmtTime(int mins) { int h=(mins/60)%24; int m=mins%60; return (h<10?"0":"")+h+":"+(m<10?"0":"")+m; }

    void addFixture(String round, String a, String b, int[] clock, int matchMin, int gapMin) throws Exception {
        JSONObject f = new JSONObject();
        f.put("round", round); f.put("teamA", a); f.put("teamB", b); f.put("time", fmtTime(clock[0]));
        fixtures.put(f); clock[0] += matchMin + gapMin;
    }

    void generateFixtures(boolean cross, boolean ipl, int poolCount, String start, int matchMin, int gapMin, int qualifiers, boolean qf, boolean semi, boolean fin, boolean losers) throws Exception {
        fixtures = new JSONArray(); int[] clock = new int[]{parseTime(start)};
        ArrayList<String> all = new ArrayList<String>();
        for (int i=0;i<teams.length();i++) all.add(teams.getJSONObject(i).optString("name"));
        if (ipl) {
            for (int i=0;i<all.size();i++) for (int j=i+1;j<all.size();j++) addFixture("IPL League", all.get(i), all.get(j), clock, matchMin, gapMin);
        } else if (cross) {
            for (int i=0;i<teams.length();i++) for (int j=i+1;j<teams.length();j++) {
                JSONObject a=teams.getJSONObject(i), b=teams.getJSONObject(j);
                if (!a.optString("pool").equals(b.optString("pool"))) addFixture("Cross Pool", a.optString("name"), b.optString("name"), clock, matchMin, gapMin);
            }
        } else {
            for (int p=0;p<poolCount;p++) {
                String pn=poolName(p); ArrayList<String> list=new ArrayList<String>();
                for (int i=0;i<teams.length();i++) if(pn.equals(teams.getJSONObject(i).optString("pool"))) list.add(teams.getJSONObject(i).optString("name"));
                for (int i=0;i<list.size();i++) for (int j=i+1;j<list.size();j++) addFixture(pn + " League", list.get(i), list.get(j), clock, matchMin, gapMin);
            }
        }
        int totalQual = Math.max(2, poolCount * qualifiers);
        ArrayList<String> q = new ArrayList<String>();
        for(int p=0;p<poolCount;p++) for(int r=1;r<=qualifiers;r++) q.add(poolName(p) + " #" + r);
        while(q.size()<totalQual) q.add("Qualifier " + (q.size()+1));
        if (qf && totalQual > 4) {
            int pairs = Math.min(4, totalQual/2);
            for(int i=0;i<pairs;i++) addFixture("Quarter Final", q.get(i), q.get(totalQual-1-i), clock, matchMin, gapMin);
            q.clear(); for(int i=1;i<=pairs;i++) q.add("QF"+i+" Winner");
        }
        if (semi && q.size() >= 4) { addFixture("Semi Final 1", q.get(0), q.get(3), clock, matchMin, gapMin); addFixture("Semi Final 2", q.get(1), q.get(2), clock, matchMin, gapMin); q.clear(); q.add("SF1 Winner"); q.add("SF2 Winner"); }
        if (losers) addFixture("Losers Final", "SF1 Loser", "SF2 Loser", clock, matchMin, gapMin);
        if (fin) addFixture("Final", q.size()>=2?q.get(0):"Finalist 1", q.size()>=2?q.get(1):"Finalist 2", clock, matchMin, gapMin);
    }

    void fixturesView() {
        base("Fixtures");
        if (fixtures.length()==0) { root.addView(tv("No fixtures generated yet.", 18, text)); addBtn("Setup Fixtures", green, v -> fixturesSetup()); addBtn("Back", panel2, v -> home()); return; }
        LinearLayout box = cardBox(); box.addView(tv("🏟️ " + sp.getString("auctionName", "Tournament") + " Fixtures", 20, gold));
        try { for(int i=0;i<fixtures.length();i++){ JSONObject f=fixtures.getJSONObject(i); box.addView(tv((i+1)+". "+f.optString("time")+"  |  "+f.optString("round")+"  |  "+f.optString("teamA")+" vs "+f.optString("teamB"), 14, text)); } } catch(Exception e) {}
        addBtn("Export Fixtures PDF", orange, v -> exportFixturesPdf());
        addBtn("Back", panel2, v -> home());
    }

    void exportFixturesPdf() {
        pdfMode = "FIXTURES"; pdfTeam = "";
        try { Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/pdf"); i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Tournament").replace(" ", "_") + "_Fixtures.pdf"); startActivityForResult(i, 7); } catch(Exception e) { toast("PDF export not supported: " + e.toString()); }
    }

    void settings() {
        base("Auction Settings");
        root.addView(label("Auction / Tournament name"));
        EditText an = input("Example: KPL Season 1");
        an.setText(sp.getString("auctionName", "KPL Season 1"));
        root.addView(label("Main squad players per team"));
        EditText ppt = input("11");
        ppt.setInputType(InputType.TYPE_CLASS_NUMBER);
        ppt.setText(String.valueOf(sp.getInt("playersPerTeam", 11)));

        CheckBox cb = new CheckBox(this);
        cb.setText("Enable bench players");
        cb.setTextColor(text);
        cb.setChecked(sp.getBoolean("bench", false));
        root.addView(cb);

        root.addView(label("Bench count per team"));
        EditText bc = input("2");
        bc.setInputType(InputType.TYPE_CLASS_NUMBER);
        bc.setText(String.valueOf(sp.getInt("benchCount", 2)));

        root.addView(label("Maximum bucket points per team"));
        EditText max = input("11000");
        max.setInputType(InputType.TYPE_CLASS_NUMBER);
        max.setText(String.valueOf(maxBucket()));

        root.addView(label("Base points per player"));
        EditText base = input("300");
        base.setInputType(InputType.TYPE_CLASS_NUMBER);
        base.setText(String.valueOf(basePoints()));

        root.addView(label("Bid increment ranges: start-end:increment"));
        EditText inc = input("300-999:50\n1000-2999:100\n3000-99999:250");
        inc.setSingleLine(false);
        inc.setMinLines(3);
        inc.setText(sp.getString("increments", "300-999:50\n1000-2999:100\n3000-99999:250"));

        LinearLayout info = cardBox();
        info.addView(tv("🏆 Professional Auction Rules", 18, gold));
        info.addView(tv("Maximum bid = current balance - ((total slots - players already bought - 1) x base points). Example: 11000 - ((11 - 0 - 1) x 300) = 8000. Edge cases handled: full squads, bid below base, over-budget bid, deleted teams, reset rounds, sold players never returning, unsold/recall-only later rounds.", 14, text));

        addBtn("Save Settings", green, v -> {
            sp.edit()
                    .putInt("playersPerTeam", Math.max(1, toInt(ppt.getText().toString(), 11)))
                    .putBoolean("bench", cb.isChecked())
                    .putInt("benchCount", Math.max(0, toInt(bc.getText().toString(), 2)))
                    .putInt("maxBucket", Math.max(0, toInt(max.getText().toString(), 11000)))
                    .putInt("basePoints", Math.max(0, toInt(base.getText().toString(), 300)))
                    .putString("increments", inc.getText().toString())
                    .putString("auctionName", an.getText().toString().trim().length()==0 ? "J's Auction Manager" : an.getText().toString().trim())
                    .apply();
            toast("Settings saved");
            home();
        });
        addBtn("Reset Auction Status Only", red, v -> {
            try {
                for (int i = 0; i < players.length(); i++) {
                    JSONObject p = players.getJSONObject(i);
                    p.put("status", "NEW");
                    p.put("team", "");
                    p.put("bid", 0);
                }
                deck = new JSONArray();
                currentIndex = -1;
                roundNo = 0;
                auctionEnded = false;
                save();
                toast("Auction reset");
                home();
            } catch (Exception e) { toast(e.toString()); }
        });
        addBtn("Clear ALL Data - Players, Teams, Auction", red, v -> confirmClearAll());
        addBtn("Back", panel2, v -> home());
    }

    void confirmClearAll() {
        new AlertDialog.Builder(this).setTitle("Clear all data?").setMessage("This deletes all players, teams, photos links, auction rounds, bids, and buckets from this app.")
                .setPositiveButton("Clear All", (d,w) -> { players = new JSONArray(); teams = new JSONArray(); deck = new JSONArray(); fixtures = new JSONArray(); currentIndex=-1; roundNo=0; auctionEnded=false; save(); toast("All data cleared"); home(); })
                .setNegativeButton("Cancel", null).show();
    }

    void exportPdf() {
        pdfMode = "ALL";
        pdfTeam = "";
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Auction").replace(" ", "_") + "_Auction_Teams_List.pdf");
            startActivityForResult(i, 7);
        } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
    }


    void playerCatalogueSettings() {
        base("Player Catalogue PDF Settings");
        root.addView(tv("Control what details should appear in the player catalogue PDF. Default professional layout shows photo, name, place, role, batting style and bowling style.", 15, text));
        CheckBox photo = new CheckBox(this); photo.setText("Show player photo"); photo.setTextColor(text); photo.setChecked(sp.getBoolean("catPhoto", true)); root.addView(photo);
        CheckBox place = new CheckBox(this); place.setText("Show place"); place.setTextColor(text); place.setChecked(sp.getBoolean("catPlace", true)); root.addView(place);
        CheckBox role = new CheckBox(this); role.setText("Show role"); role.setTextColor(text); role.setChecked(sp.getBoolean("catRole", true)); root.addView(role);
        CheckBox bat = new CheckBox(this); bat.setText("Show batting style"); bat.setTextColor(text); bat.setChecked(sp.getBoolean("catBat", true)); root.addView(bat);
        CheckBox bowl = new CheckBox(this); bowl.setText("Show bowling style"); bowl.setTextColor(text); bowl.setChecked(sp.getBoolean("catBowl", true)); root.addView(bowl);
        CheckBox mobile = new CheckBox(this); mobile.setText("Show mobile number"); mobile.setTextColor(text); mobile.setChecked(sp.getBoolean("catMobile", false)); root.addView(mobile);
        addBtn("Save Catalogue Settings", green, v -> {
            sp.edit()
                    .putBoolean("catPhoto", photo.isChecked())
                    .putBoolean("catPlace", place.isChecked())
                    .putBoolean("catRole", role.isChecked())
                    .putBoolean("catBat", bat.isChecked())
                    .putBoolean("catBowl", bowl.isChecked())
                    .putBoolean("catMobile", mobile.isChecked())
                    .apply();
            toast("Catalogue PDF settings saved");
            home();
        });
        addBtn("Export Player Catalogue PDF", gold, v -> exportPlayerCataloguePdf());
        addBtn("Back", panel2, v -> home());
    }

    void exportPlayerCataloguePdf() {
        pdfMode = "PLAYERS";
        pdfTeam = "";
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Tournament").replace(" ", "_") + "_Player_Catalogue.pdf");
            startActivityForResult(i, 7);
        } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
    }

    void exportTeamPdfScreen() {
        base("Export Separate Team PDF");
        if (teams.length() == 0) { root.addView(tv("Add teams first.", 18, text)); addBtn("Back", panel2, v -> home()); return; }
        root.addView(tv("Choose one franchise to export as a separate PDF. Icon player, if assigned, will be shown as a larger captain-style card.", 15, text));
        root.addView(label("Select Team"));
        Spinner s = teamSpinner(false);
        addBtn("Export Selected Team PDF", green, v -> {
            pdfMode = "TEAM";
            pdfTeam = s.getSelectedItem() == null ? "" : s.getSelectedItem().toString();
            try {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_TITLE, sp.getString("auctionName", "Auction").replace(" ", "_") + "_" + pdfTeam.replace(" ", "_") + ".pdf");
                startActivityForResult(i, 7);
            } catch (Exception e) { toast("PDF export not supported: " + e.toString()); }
        });
        addBtn("Back", panel2, v -> home());
    }

    void writePdf(Uri uri) {
        try {
            ensurePlayerIds();
            if ("FIXTURES".equals(pdfMode)) { writeFixturesPdf(uri); return; }
            if ("PLAYERS".equals(pdfMode)) { writePlayerCataloguePdf(uri); return; }
            PdfDocument pdf = new PdfDocument();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            int pageNo = 1;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, pageNo).create());
            Canvas c = page.getCanvas();
            int y = drawPdfHeader(c, paint, pdfMode.equals("TEAM") ? pdfTeam : "All Teams");
            for (int t = 0; t < teams.length(); t++) {
                JSONObject team = teams.getJSONObject(t); String tn = team.optString("name");
                if ("TEAM".equals(pdfMode) && !tn.equals(pdfTeam)) continue;
                if (y > 690) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c = page.getCanvas(); y = drawPdfHeader(c, paint, pdfMode.equals("TEAM") ? pdfTeam : "All Teams"); }
                y = drawTeamPdfBlock(c, paint, tn, y);
            }
            pdf.finishPage(page);
            OutputStream os = getContentResolver().openOutputStream(uri);
            pdf.writeTo(os); os.close(); pdf.close(); toast("PDF exported");
        } catch (Exception e) { toast("PDF failed: " + e.toString()); }
    }


    void writePlayerCataloguePdf(Uri uri) {
        try {
            ensurePlayerIds();
            PdfDocument pdf = new PdfDocument();
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            String tournament = sp.getString("auctionName", "Tournament");
            for (int i = 0; i < players.length(); i++) {
                JSONObject pl = players.getJSONObject(i);
                PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, i + 1).create());
                Canvas c = page.getCanvas();
                drawPlayerCataloguePage(c, p, pl, tournament, i + 1, players.length());
                pdf.finishPage(page);
            }
            OutputStream os = getContentResolver().openOutputStream(uri);
            pdf.writeTo(os); os.close(); pdf.close();
            toast("Player catalogue PDF exported");
        } catch (Exception e) { toast("Player catalogue PDF failed: " + e.toString()); }
    }

    void drawPlayerCataloguePage(Canvas c, Paint p, JSONObject pl, String tournament, int pageNo, int total) throws Exception {
        boolean showPhoto = sp.getBoolean("catPhoto", true);
        boolean showPlace = sp.getBoolean("catPlace", true);
        boolean showRole = sp.getBoolean("catRole", true);
        boolean showBat = sp.getBoolean("catBat", true);
        boolean showBowl = sp.getBoolean("catBowl", true);
        boolean showMobile = sp.getBoolean("catMobile", false);

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(4, 10, 22));
        c.drawRect(0, 0, 595, 842, p);

        // Premium header
        p.setColor(Color.rgb(93, 30, 42));
        c.drawRect(0, 0, 595, 110, p);
        p.setColor(Color.rgb(244, 184, 62));
        c.drawRect(0, 104, 595, 110, p);
        p.setFakeBoldText(true);
        p.setTextSize(24);
        p.setColor(Color.rgb(244, 184, 62));
        c.drawText("J's Auction Manager", 34, 38, p);
        p.setFakeBoldText(false);
        p.setTextSize(14);
        p.setColor(Color.WHITE);
        c.drawText(cut(tournament, 36) + " - Player Catalogue", 34, 66, p);
        p.setTextSize(10);
        p.setColor(Color.rgb(210, 218, 230));
        c.drawText("Player ID: " + pl.optString("pid", String.format(java.util.Locale.US, "%02d", pageNo)) + "  |  Player " + pageNo + " of " + total + "  |  Owned by Team RDB  |  Created by Josco", 34, 88, p);

        // Main card with safe bottom margin
        RectF card = new RectF(34, 138, 561, 765);
        p.setColor(Color.rgb(11, 22, 39));
        c.drawRoundRect(card, 28, 28, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(Color.rgb(244, 184, 62));
        c.drawRoundRect(card, 28, 28, p);
        p.setStyle(Paint.Style.FILL);

        int y;
        if (showPhoto) {
            RectF photoFrame = new RectF(82, 170, 513, 455);
            p.setColor(Color.rgb(6, 13, 26));
            c.drawRoundRect(photoFrame, 20, 20, p);
            drawPlayerPhoto(c, pl.optString("photo"), 96, 184, 403, 257, p);
            y = 502;
        } else {
            y = 205;
        }

        String playerName = pl.optString("name", "PLAYER NAME").toUpperCase();
        p.setFakeBoldText(true);
        p.setTextSize(30);
        p.setColor(Color.rgb(244, 184, 62));
        c.drawText(cut(playerName, 24), 62, y, p);
        y += 34;

        if (showRole) {
            String role = cleanRole(pl.optString("role"));
            p.setColor(roleColor(role));
            c.drawRoundRect(new RectF(62, y, 360, y + 38), 18, 18, p);
            p.setTextSize(15);
            p.setColor(Color.WHITE);
            c.drawText(cut(role.toUpperCase(), 28), 84, y + 25, p);
            y += 62;
        } else {
            y += 18;
        }

        // Clean aligned detail rows. No overflow into footer.
        y = pdfDetail(c, p, "Player ID", valueOrNA(pl.optString("pid", String.format(java.util.Locale.US, "%02d", pageNo))), y);
        if (showPlace) y = pdfDetail(c, p, "Place", valueOrNA(pl.optString("place")), y);
        if (showBat) y = pdfDetail(c, p, "Batting Style", valueOrNA(pl.optString("bat")), y);
        if (showBowl) y = pdfDetail(c, p, "Bowling Style", valueOrNA(pl.optString("bowl")), y);
        if (showMobile) y = pdfDetail(c, p, "Mobile Number", valueOrNA(pl.optString("mobile")), y);

        p.setColor(Color.rgb(244, 184, 62));
        c.drawRect(0, 798, 595, 802, p);
        p.setColor(Color.rgb(190, 202, 216));
        p.setTextSize(10);
        p.setFakeBoldText(false);
        c.drawText("© 2026 Team RDB. Proprietary player catalogue generated by J's Auction Manager.", 34, 824, p);
    }

    int pdfDetail(Canvas c, Paint p, String k, String v, int y) {
        if (y > 730) return y;
        RectF row = new RectF(62, y - 18, 533, y + 24);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(233, 240, 248));
        c.drawRoundRect(row, 12, 12, p);
        p.setFakeBoldText(true);
        p.setColor(Color.rgb(93, 30, 42));
        p.setTextSize(11);
        c.drawText(k.toUpperCase(), 82, y + 8, p);
        p.setFakeBoldText(false);
        p.setColor(Color.rgb(4, 10, 22));
        p.setTextSize(14);
        c.drawText(cut(v, 32), 248, y + 8, p);
        return y + 52;
    }

    String valueOrNA(String v) {
        if (v == null || v.trim().length() == 0) return "Not specified";
        return v.trim();
    }

    int roleColor(String role) {
        if (role == null) return Color.rgb(93, 30, 42);
        if (role.indexOf("Bowler") >= 0) return Color.rgb(36, 88, 166);
        if (role.indexOf("Round") >= 0) return Color.rgb(93, 30, 42);
        if (role.indexOf("Keeper") >= 0) return Color.rgb(22, 120, 90);
        return Color.rgb(190, 126, 16);
    }

    String cleanStatus(JSONObject pl) {
        String st = pl.optString("status", "NEW");
        if ("ICON".equals(st)) return "Icon Player - " + pl.optString("team", "Assigned Team");
        if ("SOLD".equals(st)) return "Sold to " + pl.optString("team", "") + " for " + pl.optInt("bid", 0) + " points";
        if ("UNSOLD".equals(st)) return "Unsold";
        if ("RECALL".equals(st)) return "Recall Bucket";
        return "Available for Auction";
    }

    void writeFixturesPdf(Uri uri) {
        try {
            PdfDocument pdf = new PdfDocument(); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); int pageNo=1;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); Canvas c = page.getCanvas();
            int y = drawPdfHeader(c, p, "Fixtures");
            p.setTextSize(11);
            for(int i=0;i<fixtures.length();i++) {
                if (y > 790) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c = page.getCanvas(); y = drawPdfHeader(c,p,"Fixtures"); }
                JSONObject f=fixtures.getJSONObject(i);
                p.setStyle(Paint.Style.FILL); p.setColor(i%2==0 ? Color.rgb(245,247,251) : Color.rgb(232,238,246)); c.drawRoundRect(new RectF(28,y-18,567,y+36), 12,12,p);
                p.setColor(Color.rgb(93,30,42)); p.setFakeBoldText(true); p.setTextSize(10); c.drawText(String.valueOf(i+1), 40, y+2, p);
                p.setColor(Color.rgb(5,12,24)); p.setTextSize(12); c.drawText(f.optString("time") + "  •  " + f.optString("round"), 72, y+2, p);
                p.setFakeBoldText(false); p.setTextSize(13); c.drawText(cut(f.optString("teamA"),22) + "  vs  " + cut(f.optString("teamB"),22), 72, y+24, p);
                y += 60;
            }
            pdf.finishPage(page); OutputStream os=getContentResolver().openOutputStream(uri); pdf.writeTo(os); os.close(); pdf.close(); toast("Fixtures PDF exported");
        } catch(Exception e) { toast("Fixtures PDF failed: " + e.toString()); }
    }

    int drawPdfHeader(Canvas c, Paint p, String scope) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(4, 10, 22)); c.drawRect(0,0,595,110,p);
        p.setColor(Color.rgb(93,30,42)); c.drawRect(0,96,595,110,p);
        p.setColor(Color.rgb(244,184,62)); p.setTextSize(21); p.setFakeBoldText(true);
        c.drawText(sp.getString("auctionName", "Tournament") + ("Fixtures".equals(scope) ? " Match Fixtures" : " Auction Teams List"), 28, 38, p);
        p.setColor(Color.WHITE); p.setTextSize(12); p.setFakeBoldText(false);
        c.drawText("Scope: " + scope + " | Teams: " + teams.length() + " | Players: " + players.length(), 28, 62, p);
        p.setColor(Color.rgb(190,202,216)); p.setTextSize(10);
        c.drawText("Owned by Team RDB | Creator: Josco | Copyright 2026 Team RDB", 28, 82, p);
        return 130;
    }

    int drawTeamPdfBlock(Canvas c, Paint p, String tn, int y) throws Exception {
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(236,241,247)); c.drawRoundRect(new RectF(24,y-20,571,y+34), 12, 12, p);
        p.setColor(Color.rgb(93,30,42)); p.setTextSize(15); p.setFakeBoldText(true);
        c.drawText(tn + "  | Squad: " + teamCount(tn) + "/" + totalSlots() + " | Spent: " + teamSpent(tn) + " | Balance: " + teamBalance(tn), 38, y+12, p);
        y += 58;
        JSONObject icon = null;
        for (int i=0;i<players.length();i++){ JSONObject pl=players.getJSONObject(i); if(tn.equals(pl.optString("team")) && "ICON".equals(pl.optString("status"))) { icon=pl; break; } }
        if (icon != null) {
            p.setColor(Color.rgb(255,248,224)); c.drawRoundRect(new RectF(30,y,565,y+95), 18, 18, p);
            p.setColor(Color.rgb(244,184,62)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); c.drawRoundRect(new RectF(30,y,565,y+95), 18, 18, p); p.setStyle(Paint.Style.FILL);
            drawPlayerPhoto(c, icon.optString("photo"), 42, y+12, 70, 70, p);
            p.setColor(Color.rgb(92,26,38)); p.setTextSize(18); p.setFakeBoldText(true); c.drawText("ICON PLAYER", 128, y+28, p);
            p.setColor(Color.BLACK); p.setTextSize(15); c.drawText(cut(icon.optString("name"),32), 128, y+52, p);
            p.setFakeBoldText(false); p.setTextSize(11); c.drawText("ID: " + icon.optString("pid", "--") + "  |  " + cut(cleanRole(icon.optString("role")),28), 128, y+72, p);
            y += 112;
        }
        p.setColor(Color.rgb(20,38,62)); p.setTextSize(10); p.setFakeBoldText(true);
        c.drawText("PHOTO", 34, y, p); c.drawText("ID", 92, y, p); c.drawText("PLAYER", 132, y, p); c.drawText("ROLE", 285, y, p); c.drawText("BID", 500, y, p); y += 12;
        p.setFakeBoldText(false);
        for (int i=0;i<players.length();i++) {
            JSONObject pl=players.getJSONObject(i); if(!tn.equals(pl.optString("team")) || "ICON".equals(pl.optString("status"))) continue;
            if (y > 800) return y;
            p.setColor(Color.rgb(248,250,252)); c.drawRoundRect(new RectF(30,y-4,565,y+44), 10, 10, p);
            drawPlayerPhoto(c, pl.optString("photo"), 36, y, 40, 40, p);
            p.setColor(Color.BLACK); p.setTextSize(11); p.setFakeBoldText(true); c.drawText(pl.optString("pid", "--"), 92, y+16, p); c.drawText(cut(pl.optString("name"),22), 132, y+16, p);
            p.setFakeBoldText(false); c.drawText(cut(cleanRole(pl.optString("role")),24), 285, y+16, p); c.drawText(String.valueOf(pl.optInt("bid")), 500, y+16, p);
            p.setColor(Color.DKGRAY); p.setTextSize(9); c.drawText(cut("Bat: "+pl.optString("bat")+" | Bowl: "+pl.optString("bowl"),50), 132, y+34, p);
            y += 54;
        }
        return y + 22;
    }

    void drawPlayerPhoto(Canvas c, String uri, int x, int y, int w, int h, Paint p) {
        RectF frame = new RectF(x, y, x + w, y + h);
        try {
            if (uri != null && uri.length() > 0) {
                Bitmap b = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(uri)));
                if (b != null) {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Color.rgb(6, 13, 26));
                    c.drawRoundRect(frame, 8, 8, p);

                    float bw = b.getWidth();
                    float bh = b.getHeight();
                    float scale = Math.min(w / bw, h / bh); // aspect-fit: never stretch
                    float dw = bw * scale;
                    float dh = bh * scale;
                    float left = x + (w - dw) / 2f;
                    float top = y + (h - dh) / 2f;
                    RectF dest = new RectF(left, top, left + dw, top + dh);
                    c.drawBitmap(b, null, dest, p);
                    return;
                }
            }
        } catch (Exception e) { }
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(220,225,232)); c.drawRoundRect(frame, 8, 8, p);
        p.setColor(Color.rgb(90,100,112)); p.setTextSize(10); c.drawText("PHOTO", x+8, y+h/2+4, p);
    }

    String cut(String s, int n) { return s == null ? "" : (s.length() <= n ? s : s.substring(0,n-1)); }

    public void onBackPressed() { home(); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    public class StadiumBackdrop extends View {
        Paint p = new Paint(1);
        public StadiumBackdrop(android.content.Context c) { super(c); }
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 255, 255, 255));
            for (int i = 0; i < 6; i++) {
                float x = (w / 7f) * (i + 1);
                p.setColor(Color.argb(70, 255, 230, 150));
                c.drawCircle(x, h * 0.16f, 24, p);
                p.setStrokeWidth(3);
                p.setColor(Color.argb(38, 244, 184, 62));
                c.drawLine(x, h * 0.16f, w/2f, h*0.52f, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(80, 177, 36, 47));
            c.drawOval(-w*0.15f, h*0.72f, w*1.15f, h*1.10f, p);
            p.setColor(Color.argb(110, 12, 95, 62));
            c.drawOval(-w*0.05f, h*0.77f, w*1.05f, h*1.03f, p);
            p.setColor(Color.argb(120, 244, 184, 62));
            p.setStrokeWidth(5);
            p.setStyle(Paint.Style.STROKE);
            c.drawOval(w*0.10f, h*0.80f, w*0.90f, h*0.98f, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(54);
            p.setColor(Color.argb(28, 255, 255, 255));
            c.drawText("CRICKET AUCTION", w*0.08f, h*0.92f, p);
        }
    }

}
