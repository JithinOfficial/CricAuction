# Security and Privacy Updates

- Target SDK updated to Android 15 / API 35.
- Minimum SDK raised to API 26.
- Cleartext HTTP traffic disabled.
- Network security config blocks cleartext by default.
- Android backup and device transfer disabled for app data to protect local player/team data.
- No unnecessary permissions are declared in the manifest.
- Main launcher activity explicitly sets android:exported.
- App namespace is configured in Gradle.

Build with Java 17 and Gradle 8.10.2 or newer compatible with Android Gradle Plugin 8.7.3.
