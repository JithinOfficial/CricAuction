# App Identity and Export Icon Update

Changes made:

1. New app identity
   - Application ID changed from `com.josco.jsauctions` to `com.josco.jsauctions.pro`.
   - App label changed to `RDB Auction Pro`.
   - Launcher icon replaced with a new RDB-styled vector icon.
   - This allows Android to install this build as a separate new app while keeping the existing installed app.

2. Export icon/photo options
   - All Teams PDF export now asks whether to include player photos/icons.
   - Selected Team PDF export now asks whether to include player photos/icons.
   - Player Catalogue / all players export now asks whether to include player photos/icons.
   - Existing catalogue settings are still available under More Catalogue Settings.

3. Earlier player ID changes retained
   - Deleting a player reassigns remaining player IDs sequentially.
   - Player ID is editable in Edit Player.
   - Duplicate player ID validation remains in place.

Build note:
- The uploaded project still does not include a valid Gradle wrapper JAR, so the APK could not be built in this environment.
