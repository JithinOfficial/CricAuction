# RDB Auction Manager 1.2 - God-Level Player Card Export Update

## Version
- App name: RDB Auction Manager
- Package: com.josco.jsauctionsleague
- Version code: 3
- Version name: 1.2-godlevel-cards

## Player Catalogue PDF Upgrade
- Rebuilt the player catalogue export as a full-page modern cricket auction card.
- Added stadium floodlights, pitch background, metallic gold borders, role-based gradients, trophy/bat/ball graphics, broadcast-style header, and premium player name plate.
- Export settings now dynamically build the card details grid from enabled settings.
- The following settings are respected in the PDF:
  - Player photo
  - ID photo indicator/proof
  - Player ID
  - Place
  - Role
  - Batting style
  - Bowling style
  - Mobile number
  - Team/franchise
  - Auction status
  - Bid points
  - Icon player badge/status
  - Base points
  - Exclude icon players from export

## Install/Update Notes
- Uses the existing common project signing key: app/jsauctions-common-release.jks
- Keep this key unchanged for future updates to this new app package.
- Build release APK from GitHub Actions or Android Studio.
