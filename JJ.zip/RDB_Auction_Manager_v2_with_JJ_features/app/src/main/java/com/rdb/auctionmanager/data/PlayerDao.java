package com.rdb.auctionmanager.data;
import androidx.room.*;import com.rdb.auctionmanager.model.Player;import java.util.*;
@Dao public interface PlayerDao{ @Query("SELECT * FROM Player ORDER BY id") List<Player> all(); @Query("SELECT * FROM Player WHERE status='AVAILABLE' OR status='RECALL' ORDER BY RANDOM() LIMIT 1") Player nextAuctionPlayer(); @Insert long insert(Player p); @Update void update(Player p); @Delete void delete(Player p); }
