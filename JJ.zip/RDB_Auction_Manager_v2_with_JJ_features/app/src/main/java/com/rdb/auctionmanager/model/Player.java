package com.rdb.auctionmanager.model;
import androidx.room.Entity;import androidx.room.PrimaryKey;
@Entity public class Player{ @PrimaryKey(autoGenerate=true) public long id; public String name,role,battingStyle,bowlingStyle,country,mobile,email,remarks,photoUri,status; public int age,matches,runs,wickets; public double strikeRate,economy,basePrice,soldPrice; public boolean iconPlayer; public long teamId; public Player(){country="India";status="AVAILABLE";}}
