package com.rdb.auctionmanager.data;
import androidx.room.*;import com.rdb.auctionmanager.model.Team;import java.util.*;
@Dao public interface TeamDao{ @Query("SELECT * FROM Team ORDER BY name") List<Team> all(); @Query("SELECT * FROM Team WHERE id=:id LIMIT 1") Team get(long id); @Insert long insert(Team t); @Update void update(Team t); }
