package com.rdb.auctionmanager.model;
import androidx.room.Entity;import androidx.room.PrimaryKey;
@Entity public class Team{ @PrimaryKey(autoGenerate=true) public long id; public String name,logoUri; public double bucketPoints,usedPoints; }
