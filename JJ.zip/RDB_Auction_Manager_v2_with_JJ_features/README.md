# RDB Auction Manager v2 + JJ Feature Merge

This package keeps the new v2 base and adds the feature set from the provided JJ zip.

## New v2 base included
- Java + XML Android source
- Room Database dependency and Room entities/DAO classes
- Material Design 3 theme
- Reusable `view_player_card.xml`
- PDF export engine classes
- Dynamic player photo URI support
- Dynamic team logo URI support

## Added from the provided JJ zip
- Player management with edit/delete
- Team management with logo support, edit/delete
- Offline auction flow
- Sold / Unsold / Recall handling
- Round handling with unsold + recall bucket
- Auction settings
- Players per team, bench count, base points, max bucket points
- Bid increment settings
- Team points and max biddable calculations
- Icon player handling
- Fixtures generation and fixtures PDF export
- Team-wise PDF export
- Player catalogue export settings
- Premium cricket-themed PDF catalogue rendering
- Black/gold RDB cricket UI theme
- RDB intro screen and copyright footer

## Main entry point
The active launcher activity is:

`app/src/main/java/com/rdb/auctionmanager/MainActivity.java`

This file is the JJ feature-rich activity ported into the v2 package.
The reusable XML card and Room-based v2 screens/classes are also kept in the project for further extension.

## Notes
Open in Android Studio and sync Gradle. Build Debug or Release from Android Studio/GitHub Actions.
